package com.example.framework;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WriteLogToFile {

    private static String logFilePath;

    // This runs ONCE when the class is loaded
    static {
        try {
            // Create logs folder if not exists
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdirs();
            }

            // Create file name with timestamp
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            logFilePath = "logs/run-" + timestamp + ".txt";

            // Create empty file
            File file = new File(logFilePath);
            file.createNewFile();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Call this from anywhere
    public static synchronized void addLog(String message) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(logFilePath, true))) {
            String timestamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
            writer.write("[" + timestamp + "] " + message);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
