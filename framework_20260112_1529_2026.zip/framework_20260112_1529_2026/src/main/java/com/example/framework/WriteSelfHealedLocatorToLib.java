package com.example.framework;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Writes self-healed locators back into FinalScreensPageObjects.java.
 *
 * - Creates a new By constant (e.g. USERNAME_AI_1)
 * - Adds that constant's name into FALLBACK_ORDER array
 * - Marks constant with comment: // AI Assisted self healed locator
 *
 * This uses:
 *   elementClass : FinalScreensPageObjects.LoginScreen.UsernameElement.class
 *   logicalName  : "USERNAME", "FIRST_NAME", "BTN_SUBMIT_LOGIN", etc.
 *   locatorType  : "id" | "xpath" | "css" | "accessibilityId"
 *   locatorValue : raw string from LLM
 */
public class WriteSelfHealedLocatorToLib {

    private WriteSelfHealedLocatorToLib() {}

    public static void writeHealedLocator(
            Class<?> elementClass,
            String logicalName,
            String locatorType,
            String locatorValue
    ) {
        try {
            // 1) Build path to FinalScreensPageObjects.java
            String projectRoot = System.getProperty("user.dir");
            String packagePath = elementClass.getPackageName().replace('.', '/');

            Path file = Paths.get(
                    projectRoot,
                    "src", "main", "java",
                    packagePath,
                    "FinalScreensPageObjects.java"
            );

            if (!Files.exists(file)) {
            	System.out.println("==========DEBUG :  WRITE HEALED LOCATOR TO FILE - FILE NOT FOUND ============ ");
                throw new IllegalStateException("FinalScreensPageObjects.java not found at: " + file);
            }
        	System.out.println("==========DEBUG :  WRITE HEALED LOCATOR TO FILE - FILE FOUND WRITING ============ ");

            String source = Files.readString(file, StandardCharsets.UTF_8);

            // 2) Figure out names from elementClass
            // elementClass = FinalScreensPageObjects.LoginScreen.UsernameElement
            String elementClassName = elementClass.getSimpleName(); // UsernameElement
            Class<?> screenClass = elementClass.getEnclosingClass(); // LoginScreen
            if (screenClass == null) {
                throw new IllegalStateException("Element class has no enclosing screen class: " + elementClass);
            }
            String screenClassName = screenClass.getSimpleName(); // LoginScreen

            // 3) Decide new constant name (e.g. USERNAME_AI_1, USERNAME_AI_2...)
            String baseName = logicalName.replace(".", "_").replaceAll("[^A-Za-z0-9_]", "_");
            int aiIndex = 1;
            String newConstName = baseName + "_AI_" + aiIndex;
            while (source.contains("public static final By " + newConstName)) {
                aiIndex++;
                newConstName = baseName + "_AI_" + aiIndex;
            }

            // 4) Build Java code for By.xxx("...") based on locatorType/locatorValue
            String newLocatorCode = buildByCode(locatorType, locatorValue);

            // 5) Find the screen class block
            String screenHeaderRegex =
                    "public\\s+static\\s+class\\s+" + Pattern.quote(screenClassName) + "\\s*\\{";
            Pattern screenHeaderPattern = Pattern.compile(screenHeaderRegex);
            Matcher screenHeaderMatcher = screenHeaderPattern.matcher(source);
            if (!screenHeaderMatcher.find()) {
                throw new IllegalStateException("Screen class not found: " + screenClassName);
            }

            int screenHeaderStart = screenHeaderMatcher.start();
            int screenFirstBrace = source.indexOf('{', screenHeaderMatcher.end() - 1);
            if (screenFirstBrace == -1) {
                throw new IllegalStateException("Opening brace not found for screen class: " + screenClassName);
            }

            int braceCount = 1;
            int screenEnd = -1;
            for (int i = screenFirstBrace + 1; i < source.length(); i++) {
                char c = source.charAt(i);
                if (c == '{') braceCount++;
                if (c == '}') braceCount--;
                if (braceCount == 0) {
                    screenEnd = i;
                    break;
                }
            }
            if (screenEnd == -1) {
                throw new IllegalStateException("Closing brace not found for screen class: " + screenClassName);
            }

            String beforeScreen = source.substring(0, screenHeaderStart);
            String screenBlock = source.substring(screenHeaderStart, screenEnd + 1);
            String afterScreen = source.substring(screenEnd + 1);

            // 6) Find the specific Element inner class block (UsernameElement etc.)
            String elementHeaderRegex =
                    "public\\s+static\\s+class\\s+" + Pattern.quote(elementClassName) + "\\s*\\{";
            Pattern elementHeaderPattern = Pattern.compile(elementHeaderRegex);
            Matcher elementHeaderMatcher = elementHeaderPattern.matcher(screenBlock);
            if (!elementHeaderMatcher.find()) {
                throw new IllegalStateException("Element class not found: " + elementClassName);
            }

            int elemHeaderStart = elementHeaderMatcher.start();
            int elemFirstBrace = screenBlock.indexOf('{', elementHeaderMatcher.end() - 1);
            if (elemFirstBrace == -1) {
                throw new IllegalStateException("Opening brace not found for element class: " + elementClassName);
            }

            braceCount = 1;
            int elemEnd = -1;
            for (int i = elemFirstBrace + 1; i < screenBlock.length(); i++) {
                char c = screenBlock.charAt(i);
                if (c == '{') braceCount++;
                if (c == '}') braceCount--;
                if (braceCount == 0) {
                    elemEnd = i;
                    break;
                }
            }
            if (elemEnd == -1) {
                throw new IllegalStateException("Closing brace not found for element class: " + elementClassName);
            }

            String beforeElement = screenBlock.substring(0, elemHeaderStart);
            String elementBlock = screenBlock.substring(elemHeaderStart, elemEnd + 1);
            String afterElement = screenBlock.substring(elemEnd + 1);

            // 7) Insert new By constant after the last existing By constant in this element
            Pattern byConstPattern = Pattern.compile(
                    "public\\s+static\\s+final\\s+By\\s+[A-Z0-9_]+\\s*=\\s*[^;]+;",
                    Pattern.DOTALL
            );
            Matcher byMatcher = byConstPattern.matcher(elementBlock);
            int lastByEnd = -1;
            while (byMatcher.find()) {
                lastByEnd = byMatcher.end();
            }
            if (lastByEnd == -1) {
                throw new IllegalStateException("No By constants found in element: " + elementClassName);
            }

            String nl = System.lineSeparator();
            String fieldIndent = "            "; // 12 spaces, close enough to your indentation

            String newConstLine =
                    nl +
                    fieldIndent +
                    "public static final By " + newConstName + " = " +
                    newLocatorCode +
                    "; // AI Assisted self healed locator" +
                    nl;

            elementBlock =
                    elementBlock.substring(0, lastByEnd) +
                    newConstLine +
                    elementBlock.substring(lastByEnd);

            // 8) Update FALLBACK_ORDER to add the new constant name
            String fallbackRegex =
                    "(\\s*)public\\s+static\\s+final\\s+String\\[\\]\\s+FALLBACK_ORDER\\s*=\\s*new\\s+String\\[\\]\\s*\\{([^}]*)\\};";
            Pattern fallbackPattern = Pattern.compile(fallbackRegex, Pattern.DOTALL);
            Matcher fallbackMatcher = fallbackPattern.matcher(elementBlock);

            if (fallbackMatcher.find()) {
                String indent = fallbackMatcher.group(1);
                String body = fallbackMatcher.group(2); // inside { ... }

                if (!body.contains("\"" + newConstName + "\"")) {
                    String trimmed = body.trim();
                    String newBody;
                    if (trimmed.isEmpty()) {
                        newBody = " \"" + newConstName + "\" ";
                    } else {
                        if (!trimmed.endsWith(",")) {
                            trimmed = trimmed + ", ";
                        }
                        newBody = trimmed + "\"" + newConstName + "\"";
                    }

                    String replacement =
                            indent +
                            "public static final String[] FALLBACK_ORDER = new String[] {" +
                            newBody +
                            "};";

                    elementBlock = fallbackMatcher.replaceFirst(replacement);
                }
            } else {
                // No FALLBACK_ORDER yet – create one before closing brace
                int lastBrace = elementBlock.lastIndexOf('}');
                if (lastBrace == -1) {
                    throw new IllegalStateException("No closing brace in element class: " + elementClassName);
                }
                String fallbackDecl =
                        nl +
                        fieldIndent +
                        "public static final String[] FALLBACK_ORDER = new String[] { \"" +
                        newConstName +
                        "\" };" +
                        nl;

                elementBlock =
                        elementBlock.substring(0, lastBrace) +
                        fallbackDecl +
                        elementBlock.substring(lastBrace);
            }

            // 9) Rebuild full source and write file
            String newScreenBlock = beforeElement + elementBlock + afterElement;
            String updatedSource = beforeScreen + newScreenBlock + afterScreen;

            Files.writeString(
                    file,
                    updatedSource,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.TRUNCATE_EXISTING
            );

            System.out.println("[SelfHeal-Lib] Added " + newConstName +
                    " and updated FALLBACK_ORDER in " +
                    screenClassName + "." + elementClassName);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("[SelfHeal-Lib] Failed to update FinalScreensPageObjects.java: " + e.getMessage());
        }
    }

    /**
     * Convert locatorType + locatorValue FROM LLM into a Java By expression string.
     *
     * locatorType comes from your HealedLocator.locatorType:
     *   "id" | "xpath" | "css" | "accessibilityId" (and variants)
     */
    private static String buildByCode(String locatorType, String locatorValue) {
        String t = (locatorType == null) ? "" : locatorType.trim().toLowerCase();
        if (locatorValue == null) locatorValue = "";

        // Escape for Java string literal
        String v = locatorValue
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");

        switch (t) {
            case "id":
                return "By.id(\"" + v + "\")";
            case "css":
                return "By.cssSelector(\"" + v + "\")";
            case "accessibilityid":
            case "accessibility_id":
            case "accessibility":
                // Your framework currently uses Selenium By only; emulate accessibility via xpath
                return "By.xpath(\"//*[@content-desc='" + v.replace("'", "\\'") + "']\")";
            case "xpath":
            default:
                return "By.xpath(\"" + v + "\")";
        }
    }
}
