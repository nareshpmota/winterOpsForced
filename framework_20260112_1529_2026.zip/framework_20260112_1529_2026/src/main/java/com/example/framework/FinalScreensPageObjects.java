package com.example.framework;

import org.openqa.selenium.By;

public class FinalScreensPageObjects {

    public static class SelectStation {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class Select_an_item__Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SELECT_AN_ITEM
            public static String HINT = "CLICK SELECT_AN_ITEM";

            public static final By SELECT_AN_ITEM__1 = By.xpath("//*[normalize-space(@text)='Select an item ']");
            public static final By SELECT_AN_ITEM__2 = By.xpath("//android.widget.Spinner[@text='Select an item ']");

            public static final String[] FALLBACK_ORDER = new String[] {"SELECT_AN_ITEM__1", "SELECT_AN_ITEM__2"};
        }

        public static class SaveElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SAVE
            public static String HINT = "CLICK SAVE";

            public static final By SAVE1 = By.xpath("//*[normalize-space(@text)='Save']");
            public static final By SAVE2 = By.xpath("//android.widget.Button[@text='Save']");

            public static final String[] FALLBACK_ORDER = new String[] {"SAVE1", "SAVE2"};
        }

        public static class BackBtnElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACKBTN1 = By.xpath("//*[contains(@resource-id,'BackBtn')]");
            public static final By BACKBTN2 = By.xpath("//*[@resource-id='BackBtn']");
            public static final By BACKBTN3 = By.xpath("//*[@resource-id='BackBtn']");
            public static final By BACKBTN4 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACKBTN5 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACKBTN1", "BACKBTN2", "BACKBTN3", "BACKBTN4", "BACKBTN5"};
        }

        public static class ABE__Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By ABE__1 = By.xpath("//*[normalize-space(@text)='ABE ']");
            public static final By ABE__2 = By.xpath("//android.widget.Spinner[@text='ABE ']");

            public static final String[] FALLBACK_ORDER = new String[] {"ABE__1", "ABE__2"};
        }

    }

    public static class PPRLogin {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class Input_EmployeeNumberValueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"008720216\" INTO Input_EmployeeNumberValue
            public static String HINT = "TYPE \"008720216\" INTO Input_EmployeeNumberValue";

            public static final By INPUT_EMPLOYEENUMBERVALUE1 = By.xpath("//*[contains(@resource-id,'Input_EmployeeNumberValue')]");
            public static final By INPUT_EMPLOYEENUMBERVALUE2 = By.xpath("//*[@resource-id='Input_EmployeeNumberValue']");
            public static final By INPUT_EMPLOYEENUMBERVALUE3 = By.xpath("//*[@resource-id='Input_EmployeeNumberValue']");
            public static final By INPUT_EMPLOYEENUMBERVALUE4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_EMPLOYEENUMBERVALUE1", "INPUT_EMPLOYEENUMBERVALUE2", "INPUT_EMPLOYEENUMBERVALUE3", "INPUT_EMPLOYEENUMBERVALUE4"};
        }

        public static class ContinueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK CONTINUE
            public static String HINT = "CLICK CONTINUE";

            public static final By CONTINUE1 = By.xpath("//*[normalize-space(@text)='Continue']");
            public static final By CONTINUE2 = By.xpath("//android.widget.Button[@text='Continue']");

            public static final String[] FALLBACK_ORDER = new String[] {"CONTINUE1", "CONTINUE2"};
        }

    }

    public static class SUMMARY {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackBtnElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACKBTN1 = By.xpath("//*[contains(@resource-id,'BackBtn')]");
            public static final By BACKBTN2 = By.xpath("//*[@resource-id='BackBtn']");
            public static final By BACKBTN3 = By.xpath("//*[@resource-id='BackBtn']");
            public static final By BACKBTN4 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACKBTN5 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACKBTN1", "BACKBTN2", "BACKBTN3", "BACKBTN4", "BACKBTN5"};
        }

        public static class RadioButton1_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON1_INPUT1 = By.xpath("//*[contains(@resource-id,'RadioButton1-input')]");
            public static final By RADIOBUTTON1_INPUT2 = By.xpath("//*[@resource-id='RadioButton1-input']");
            public static final By RADIOBUTTON1_INPUT3 = By.xpath("//*[@resource-id='RadioButton1-input']");
            public static final By RADIOBUTTON1_INPUT4 = By.xpath("//*[normalize-space(@text)='Yes']");
            public static final By RADIOBUTTON1_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Yes']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON1_INPUT1", "RADIOBUTTON1_INPUT2", "RADIOBUTTON1_INPUT3", "RADIOBUTTON1_INPUT4", "RADIOBUTTON1_INPUT5"};
        }

        public static class RadioButton2_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON2_INPUT1 = By.xpath("//*[contains(@resource-id,'RadioButton2-input')]");
            public static final By RADIOBUTTON2_INPUT2 = By.xpath("//*[@resource-id='RadioButton2-input']");
            public static final By RADIOBUTTON2_INPUT3 = By.xpath("//*[@resource-id='RadioButton2-input']");
            public static final By RADIOBUTTON2_INPUT4 = By.xpath("//*[normalize-space(@text)='No']");
            public static final By RADIOBUTTON2_INPUT5 = By.xpath("//android.widget.RadioButton[@text='No']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON2_INPUT1", "RADIOBUTTON2_INPUT2", "RADIOBUTTON2_INPUT3", "RADIOBUTTON2_INPUT4", "RADIOBUTTON2_INPUT5"};
        }

        public static class AcknowledgmentCheckBoxElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK AcknowledgmentCheckBox
            public static String HINT = "CLICK AcknowledgmentCheckBox";

            public static final By ACKNOWLEDGMENTCHECKBOX1 = By.xpath("//*[contains(@resource-id,'AcknowledgmentCheckBox')]");
            public static final By ACKNOWLEDGMENTCHECKBOX2 = By.xpath("//*[@resource-id='AcknowledgmentCheckBox']");
            public static final By ACKNOWLEDGMENTCHECKBOX3 = By.xpath("//*[@resource-id='AcknowledgmentCheckBox']");
            public static final By ACKNOWLEDGMENTCHECKBOX4 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"ACKNOWLEDGMENTCHECKBOX1", "ACKNOWLEDGMENTCHECKBOX2", "ACKNOWLEDGMENTCHECKBOX3", "ACKNOWLEDGMENTCHECKBOX4"};
        }

        public static class TextArea_CommentElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST COMMENTS\" INTO TextArea_Comment
            public static String HINT = "TYPE \"TEST COMMENTS\" INTO TextArea_Comment";

            public static final By TEXTAREA_COMMENT1 = By.xpath("//*[contains(@resource-id,'TextArea_Comment')]");
            public static final By TEXTAREA_COMMENT2 = By.xpath("//*[@resource-id='TextArea_Comment']");
            public static final By TEXTAREA_COMMENT3 = By.xpath("//*[@resource-id='TextArea_Comment']");
            public static final By TEXTAREA_COMMENT4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"TEXTAREA_COMMENT1", "TEXTAREA_COMMENT2", "TEXTAREA_COMMENT3", "TEXTAREA_COMMENT4"};
        }

        public static class SubmitElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Submit
            public static String HINT = "CLICK Submit";

            public static final By SUBMIT1 = By.xpath("//*[normalize-space(@text)='Submit']");
            public static final By SUBMIT2 = By.xpath("//android.widget.Button[@text='Submit']");

            public static final String[] FALLBACK_ORDER = new String[] {"SUBMIT1", "SUBMIT2"};
        }

    }

    public static class TruckInformation {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class Input_VehicleNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST Vehicle\" INTO VEHICLE_NUMBER_INPUT
            public static String HINT = "TYPE \"TEST Vehicle\" INTO VEHICLE_NUMBER_INPUT";

            public static final By INPUT_VEHICLENUMBER1 = By.xpath("//*[contains(@resource-id,'Input_VehicleNumber')]");
            public static final By INPUT_VEHICLENUMBER2 = By.xpath("//*[@resource-id='Input_VehicleNumber']");
            public static final By INPUT_VEHICLENUMBER3 = By.xpath("//*[@resource-id='Input_VehicleNumber']");
            public static final By INPUT_VEHICLENUMBER4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_VEHICLENUMBER1", "INPUT_VEHICLENUMBER2", "INPUT_VEHICLENUMBER3", "INPUT_VEHICLENUMBER4"};
        }

        public static class Checkbox2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK INSPECT_VEHICLE_COMPLETE_POI_CHECKBOX
            public static String HINT = "CLICK INSPECT_VEHICLE_COMPLETE_POI_CHECKBOX";

            public static final By CHECKBOX21 = By.xpath("//*[contains(@resource-id,'Checkbox2')]");
            public static final By CHECKBOX22 = By.xpath("//*[@resource-id='Checkbox2']");
            public static final By CHECKBOX23 = By.xpath("//*[@resource-id='Checkbox2']");
            public static final By CHECKBOX24 = By.xpath("//*[normalize-space(@text)='Inspect the vehicle / complete POI*']");
            public static final By CHECKBOX25 = By.xpath("//android.widget.CheckBox[@text='Inspect the vehicle / complete POI*']");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX21", "CHECKBOX22", "CHECKBOX23", "CHECKBOX24", "CHECKBOX25"};
        }

        public static class Checkbox1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK CHECKBOX1
            public static String HINT = "CLICK CHECKBOX1";

            public static final By CHECKBOX11 = By.xpath("//*[contains(@resource-id,'Checkbox1')]");
            public static final By CHECKBOX12 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX13 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX14 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX11", "CHECKBOX12", "CHECKBOX13", "CHECKBOX14"};
        }

        public static class Dropdown1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By DROPDOWN11 = By.xpath("//*[contains(@resource-id,'Dropdown1')]");
            public static final By DROPDOWN12 = By.xpath("//*[@resource-id='Dropdown1']");
            public static final By DROPDOWN13 = By.xpath("//*[@resource-id='Dropdown1']");
            public static final By DROPDOWN14 = By.xpath("//*[normalize-space(@text)='DOW UCAR PG ADF']");
            public static final By DROPDOWN15 = By.xpath("//android.view.View[@text='DOW UCAR PG ADF']");

            public static final String[] FALLBACK_ORDER = new String[] {"DROPDOWN11", "DROPDOWN12", "DROPDOWN13", "DROPDOWN14", "DROPDOWN15"};
        }

        public static class Input_FluidTypeI_FreezePointElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK FLUID_TYPE_I_FREEZE_POINT_INPUT
            public static String HINT = "CLICK FLUID_TYPE_I_FREEZE_POINT_INPUT";

            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_FreezePoint')]");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT2 = By.xpath("//*[@resource-id='Input_FluidTypeI_FreezePoint']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT3 = By.xpath("//*[@resource-id='Input_FluidTypeI_FreezePoint']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT4 = By.xpath("//*[normalize-space(@text)='Fluid Type I Freeze Point*']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT5 = By.xpath("//android.widget.EditText[@text='Fluid Type I Freeze Point*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_FREEZEPOINT1", "INPUT_FLUIDTYPEI_FREEZEPOINT2", "INPUT_FLUIDTYPEI_FREEZEPOINT3", "INPUT_FLUIDTYPEI_FREEZEPOINT4", "INPUT_FLUIDTYPEI_FREEZEPOINT5"};
        }

        public static class Input_FluidTypeI_DilutionElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK FLUID_TYPE_I_DILUTION_INPUT
            public static String HINT = "CLICK FLUID_TYPE_I_DILUTION_INPUT";

            public static final By INPUT_FLUIDTYPEI_DILUTION1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_Dilution')]");
            public static final By INPUT_FLUIDTYPEI_DILUTION2 = By.xpath("//*[@resource-id='Input_FluidTypeI_Dilution']");
            public static final By INPUT_FLUIDTYPEI_DILUTION3 = By.xpath("//*[@resource-id='Input_FluidTypeI_Dilution']");
            public static final By INPUT_FLUIDTYPEI_DILUTION4 = By.xpath("//*[normalize-space(@text)='Fluid Type I Dilution (%) - Glycol Only']");
            public static final By INPUT_FLUIDTYPEI_DILUTION5 = By.xpath("//android.widget.EditText[@text='Fluid Type I Dilution (%) - Glycol Only']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_DILUTION1", "INPUT_FLUIDTYPEI_DILUTION2", "INPUT_FLUIDTYPEI_DILUTION3", "INPUT_FLUIDTYPEI_DILUTION4", "INPUT_FLUIDTYPEI_DILUTION5"};
        }

        public static class Dropdown2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By DROPDOWN21 = By.xpath("//*[contains(@resource-id,'Dropdown2')]");
            public static final By DROPDOWN22 = By.xpath("//*[@resource-id='Dropdown2']");
            public static final By DROPDOWN23 = By.xpath("//*[@resource-id='Dropdown2']");
            public static final By DROPDOWN24 = By.xpath("//*[normalize-space(@text)='DOW Flight Guard AD-49']");
            public static final By DROPDOWN25 = By.xpath("//android.view.View[@text='DOW Flight Guard AD-49']");

            public static final String[] FALLBACK_ORDER = new String[] {"DROPDOWN21", "DROPDOWN22", "DROPDOWN23", "DROPDOWN24", "DROPDOWN25"};
        }

        public static class Input_FluidTypeIV_DilutionElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK FluidTypeIV_Dilution
            public static String HINT = "CLICK FluidTypeIV_Dilution";

            public static final By INPUT_FLUIDTYPEIV_DILUTION1 = By.xpath("//*[normalize-space(@text)='100']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION2 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_Dilution')]");
            public static final By INPUT_FLUIDTYPEIV_DILUTION3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION4 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION5 = By.xpath("//android.view.View[@text='100']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_DILUTION1", "INPUT_FLUIDTYPEIV_DILUTION2", "INPUT_FLUIDTYPEIV_DILUTION3", "INPUT_FLUIDTYPEIV_DILUTION4", "INPUT_FLUIDTYPEIV_DILUTION5"};
        }

        public static class Input_FluidTypeIV_RIElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK FLUID_TYPE_IV_RI
            public static String HINT = "CLICK FLUID_TYPE_IV_RI";

            public static final By INPUT_FLUIDTYPEIV_RI1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_RI')]");
            public static final By INPUT_FLUIDTYPEIV_RI2 = By.xpath("//*[@resource-id='Input_FluidTypeIV_RI']");
            public static final By INPUT_FLUIDTYPEIV_RI3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_RI']");
            public static final By INPUT_FLUIDTYPEIV_RI4 = By.xpath("//*[normalize-space(@text)='Fluid Type IV RI*']");
            public static final By INPUT_FLUIDTYPEIV_RI5 = By.xpath("//android.widget.EditText[@text='Fluid Type IV RI*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_RI1", "INPUT_FLUIDTYPEIV_RI2", "INPUT_FLUIDTYPEIV_RI3", "INPUT_FLUIDTYPEIV_RI4", "INPUT_FLUIDTYPEIV_RI5"};
        }

        public static class SaveBtnElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SAVE
            public static String HINT = "CLICK SAVE";

            public static final By SAVEBTN1 = By.xpath("//*[contains(@resource-id,'SaveBtn')]");
            public static final By SAVEBTN2 = By.xpath("//*[@resource-id='SaveBtn']");
            public static final By SAVEBTN3 = By.xpath("//*[@resource-id='SaveBtn']");
            public static final By SAVEBTN4 = By.xpath("//*[normalize-space(@text)='Save']");
            public static final By SAVEBTN5 = By.xpath("//android.widget.Button[@text='Save']");

            public static final String[] FALLBACK_ORDER = new String[] {"SAVEBTN1", "SAVEBTN2", "SAVEBTN3", "SAVEBTN4", "SAVEBTN5"};
        }

        public static class Text1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TEXT11 = By.xpath("//*[normalize-space(@text)='100']");
            public static final By TEXT12 = By.xpath("//*[contains(@resource-id,'android:id/text1')]");
            public static final By TEXT13 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT14 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT15 = By.xpath("//android.widget.CheckedTextView[@text='100']");

            public static final String[] FALLBACK_ORDER = new String[] {"TEXT11", "TEXT12", "TEXT13", "TEXT14", "TEXT15"};
        }

        public static class Text1Element_2 {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK 75
            public static String HINT = "CLICK 75";

            public static final By TEXT11 = By.xpath("//*[normalize-space(@text)='75']");
            public static final By TEXT12 = By.xpath("//*[contains(@resource-id,'android:id/text1')]");
            public static final By TEXT13 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT14 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT15 = By.xpath("//android.widget.CheckedTextView[@text='75']");

            public static final String[] FALLBACK_ORDER = new String[] {"TEXT11", "TEXT12", "TEXT13", "TEXT14", "TEXT15"};
        }

        public static class Text1Element_3 {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TEXT11 = By.xpath("//*[normalize-space(@text)='50']");
            public static final By TEXT12 = By.xpath("//*[contains(@resource-id,'android:id/text1')]");
            public static final By TEXT13 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT14 = By.xpath("//*[@resource-id='android:id/text1']");
            public static final By TEXT15 = By.xpath("//android.widget.CheckedTextView[@text='50']");

            public static final String[] FALLBACK_ORDER = new String[] {"TEXT11", "TEXT12", "TEXT13", "TEXT14", "TEXT15"};
        }

        public static class Input_FluidTypeIV_DilutionElement_2 {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEIV_DILUTION1 = By.xpath("//*[normalize-space(@text)='75']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION2 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_Dilution')]");
            public static final By INPUT_FLUIDTYPEIV_DILUTION3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION4 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION5 = By.xpath("//android.view.View[@text='75']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_DILUTION1", "INPUT_FLUIDTYPEIV_DILUTION2", "INPUT_FLUIDTYPEIV_DILUTION3", "INPUT_FLUIDTYPEIV_DILUTION4", "INPUT_FLUIDTYPEIV_DILUTION5"};
        }

    }

    public static class TypeIVFluidApplication {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACK1 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACK2 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACK1", "BACK2"};
        }

        public static class ButtonGroupItem1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK Type_IV_Used
            public static String HINT = "CLICK Type_IV_Used";

            public static final By BUTTONGROUPITEM11 = By.xpath("//*[contains(@resource-id,'ButtonGroupItem1')]");
            public static final By BUTTONGROUPITEM12 = By.xpath("//*[@resource-id='ButtonGroupItem1']");
            public static final By BUTTONGROUPITEM13 = By.xpath("//*[@resource-id='ButtonGroupItem1']");
            public static final By BUTTONGROUPITEM14 = By.xpath("//*[normalize-space(@text)='Type IV Used']");
            public static final By BUTTONGROUPITEM15 = By.xpath("//android.widget.RadioButton[@text='Type IV Used']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTONGROUPITEM11", "BUTTONGROUPITEM12", "BUTTONGROUPITEM13", "BUTTONGROUPITEM14", "BUTTONGROUPITEM15"};
        }

        public static class ButtonGroupItem2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTONGROUPITEM21 = By.xpath("//*[contains(@resource-id,'ButtonGroupItem2')]");
            public static final By BUTTONGROUPITEM22 = By.xpath("//*[@resource-id='ButtonGroupItem2']");
            public static final By BUTTONGROUPITEM23 = By.xpath("//*[@resource-id='ButtonGroupItem2']");
            public static final By BUTTONGROUPITEM24 = By.xpath("//*[normalize-space(@text)='Type IV Not Used']");
            public static final By BUTTONGROUPITEM25 = By.xpath("//android.widget.RadioButton[@text='Type IV Not Used']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTONGROUPITEM21", "BUTTONGROUPITEM22", "BUTTONGROUPITEM23", "BUTTONGROUPITEM24", "BUTTONGROUPITEM25"};
        }

        public static class Input_FluidTypeI_StartDateTimeElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Input_FluidTypeI_StartDateTime
            public static String HINT = "CLICK Input_FluidTypeI_StartDateTime";

            public static final By INPUT_FLUIDTYPEI_STARTDATETIME1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_StartDateTime')]");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME2 = By.xpath("//*[@resource-id='Input_FluidTypeI_StartDateTime']");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME3 = By.xpath("//*[@resource-id='Input_FluidTypeI_StartDateTime']");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME4 = By.className("android.widget.Spinner");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_STARTDATETIME1", "INPUT_FLUIDTYPEI_STARTDATETIME2", "INPUT_FLUIDTYPEI_STARTDATETIME3", "INPUT_FLUIDTYPEI_STARTDATETIME4"};
        }

        public static class Input_FluidTypeI_EndDateTimeElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Input_FluidTypeI_EndDateTime
            public static String HINT = "CLICK Input_FluidTypeI_EndDateTime";

            public static final By INPUT_FLUIDTYPEI_ENDDATETIME1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_EndDateTime')]");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME2 = By.xpath("//*[@resource-id='Input_FluidTypeI_EndDateTime']");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME3 = By.xpath("//*[@resource-id='Input_FluidTypeI_EndDateTime']");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME4 = By.className("android.widget.Spinner");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_ENDDATETIME1", "INPUT_FLUIDTYPEI_ENDDATETIME2", "INPUT_FLUIDTYPEI_ENDDATETIME3", "INPUT_FLUIDTYPEI_ENDDATETIME4"};
        }

        public static class Input_FluidTypeI_GallonsUsedElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Type_IV_Gallons_Applied
            public static String HINT = "CLICK Type_IV_Gallons_Applied";

            public static final By INPUT_FLUIDTYPEI_GALLONSUSED1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_GallonsUsed')]");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED2 = By.xpath("//*[@resource-id='Input_FluidTypeI_GallonsUsed']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED3 = By.xpath("//*[@resource-id='Input_FluidTypeI_GallonsUsed']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED4 = By.xpath("//*[normalize-space(@text)='Type IV Gallons Applied*']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED5 = By.xpath("//android.widget.EditText[@text='Type IV Gallons Applied*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_GALLONSUSED1", "INPUT_FLUIDTYPEI_GALLONSUSED2", "INPUT_FLUIDTYPEI_GALLONSUSED3", "INPUT_FLUIDTYPEI_GALLONSUSED4", "INPUT_FLUIDTYPEI_GALLONSUSED5"};
        }

        public static class Checkbox1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CHECKBOX11 = By.xpath("//*[contains(@resource-id,'Checkbox1')]");
            public static final By CHECKBOX12 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX13 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX14 = By.xpath("//*[normalize-space(@text)='Read from meter']");
            public static final By CHECKBOX15 = By.xpath("//android.widget.CheckBox[@text='Read from meter']");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX11", "CHECKBOX12", "CHECKBOX13", "CHECKBOX14", "CHECKBOX15"};
        }

        public static class Input_FluidTypeIV_ProductValueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEIV_PRODUCTVALUE1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_ProductValue')]");
            public static final By INPUT_FLUIDTYPEIV_PRODUCTVALUE2 = By.xpath("//*[@resource-id='Input_FluidTypeIV_ProductValue']");
            public static final By INPUT_FLUIDTYPEIV_PRODUCTVALUE3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_ProductValue']");
            public static final By INPUT_FLUIDTYPEIV_PRODUCTVALUE4 = By.xpath("//*[normalize-space(@text)='DOW Flight Guard AD-49']");
            public static final By INPUT_FLUIDTYPEIV_PRODUCTVALUE5 = By.xpath("//android.widget.EditText[@text='DOW Flight Guard AD-49']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_PRODUCTVALUE1", "INPUT_FLUIDTYPEIV_PRODUCTVALUE2", "INPUT_FLUIDTYPEIV_PRODUCTVALUE3", "INPUT_FLUIDTYPEIV_PRODUCTVALUE4", "INPUT_FLUIDTYPEIV_PRODUCTVALUE5"};
        }

        public static class Input_FluidTypeIV_DilutionElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEIV_DILUTION1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_Dilution')]");
            public static final By INPUT_FLUIDTYPEIV_DILUTION2 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_Dilution']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION4 = By.xpath("//*[normalize-space(@text)='75, Type IV Glycol Dilution*']");
            public static final By INPUT_FLUIDTYPEIV_DILUTION5 = By.xpath("//android.widget.EditText[@text='75, Type IV Glycol Dilution*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_DILUTION1", "INPUT_FLUIDTYPEIV_DILUTION2", "INPUT_FLUIDTYPEIV_DILUTION3", "INPUT_FLUIDTYPEIV_DILUTION4", "INPUT_FLUIDTYPEIV_DILUTION5"};
        }

        public static class E_56Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_561 = By.xpath("//*[normalize-space(@text)='56']");
            public static final By E_562 = By.xpath("//android.widget.Button[@text='56']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_561", "E_562"};
        }

        public static class E_58Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_581 = By.xpath("//*[normalize-space(@text)='58']");
            public static final By E_582 = By.xpath("//android.widget.Button[@text='58']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_581", "E_582"};
        }

        public static class Button3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTON31 = By.xpath("//*[contains(@resource-id,'android:id/button3')]");
            public static final By BUTTON32 = By.xpath("//*[@resource-id='android:id/button3']");
            public static final By BUTTON33 = By.xpath("//*[@resource-id='android:id/button3']");
            public static final By BUTTON34 = By.xpath("//*[normalize-space(@text)='CLEAR']");
            public static final By BUTTON35 = By.xpath("//android.widget.Button[@text='CLEAR']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON31", "BUTTON32", "BUTTON33", "BUTTON34", "BUTTON35"};
        }

        public static class Button2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTON21 = By.xpath("//*[contains(@resource-id,'android:id/button2')]");
            public static final By BUTTON22 = By.xpath("//*[@resource-id='android:id/button2']");
            public static final By BUTTON23 = By.xpath("//*[@resource-id='android:id/button2']");
            public static final By BUTTON24 = By.xpath("//*[normalize-space(@text)='CANCEL']");
            public static final By BUTTON25 = By.xpath("//android.widget.Button[@text='CANCEL']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON21", "BUTTON22", "BUTTON23", "BUTTON24", "BUTTON25"};
        }

        public static class Button1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SET
            public static String HINT = "CLICK SET";

            public static final By BUTTON11 = By.xpath("//*[contains(@resource-id,'android:id/button1')]");
            public static final By BUTTON12 = By.xpath("//*[@resource-id='android:id/button1']");
            public static final By BUTTON13 = By.xpath("//*[@resource-id='android:id/button1']");
            public static final By BUTTON14 = By.xpath("//*[normalize-space(@text)='SET']");
            public static final By BUTTON15 = By.xpath("//android.widget.Button[@text='SET']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON11", "BUTTON12", "BUTTON13", "BUTTON14", "BUTTON15"};
        }

        public static class E_57Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_571 = By.xpath("//*[normalize-space(@text)='57']");
            public static final By E_572 = By.xpath("//android.widget.Button[@text='57']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_571", "E_572"};
        }

        public static class E_59Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_591 = By.xpath("//*[normalize-space(@text)='59']");
            public static final By E_592 = By.xpath("//android.widget.Button[@text='59']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_591", "E_592"};
        }

        public static class Input_FluidTypeIV_RIElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEIV_RI1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeIV_RI')]");
            public static final By INPUT_FLUIDTYPEIV_RI2 = By.xpath("//*[@resource-id='Input_FluidTypeIV_RI']");
            public static final By INPUT_FLUIDTYPEIV_RI3 = By.xpath("//*[@resource-id='Input_FluidTypeIV_RI']");
            public static final By INPUT_FLUIDTYPEIV_RI4 = By.xpath("//*[normalize-space(@text)='10, Type IV RI*']");
            public static final By INPUT_FLUIDTYPEIV_RI5 = By.xpath("//android.widget.EditText[@text='10, Type IV RI*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEIV_RI1", "INPUT_FLUIDTYPEIV_RI2", "INPUT_FLUIDTYPEIV_RI3", "INPUT_FLUIDTYPEIV_RI4", "INPUT_FLUIDTYPEIV_RI5"};
        }

        public static class SaveElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SAVE
            public static String HINT = "CLICK SAVE";

            public static final By SAVE1 = By.xpath("//*[normalize-space(@text)='Save']");
            public static final By SAVE2 = By.xpath("//android.widget.Button[@text='Save']");

            public static final String[] FALLBACK_ORDER = new String[] {"SAVE1", "SAVE2"};
        }

    }

    public static class OperatorsScreen {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class CancelElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CANCEL1 = By.xpath("//*[normalize-space(@text)='Cancel']");
            public static final By CANCEL2 = By.xpath("//android.widget.Button[@text='Cancel']");

            public static final String[] FALLBACK_ORDER = new String[] {"CANCEL1", "CANCEL2"};
        }

        public static class Input_DriverPersonNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_DRIVERPERSONNUMBER1 = By.xpath("//*[contains(@resource-id,'Input_DriverPersonNumber')]");
            public static final By INPUT_DRIVERPERSONNUMBER2 = By.xpath("//*[@resource-id='Input_DriverPersonNumber']");
            public static final By INPUT_DRIVERPERSONNUMBER3 = By.xpath("//*[@resource-id='Input_DriverPersonNumber']");
            public static final By INPUT_DRIVERPERSONNUMBER4 = By.xpath("//*[normalize-space(@text)='008720216']");
            public static final By INPUT_DRIVERPERSONNUMBER5 = By.xpath("//android.widget.EditText[@text='008720216']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_DRIVERPERSONNUMBER1", "INPUT_DRIVERPERSONNUMBER2", "INPUT_DRIVERPERSONNUMBER3", "INPUT_DRIVERPERSONNUMBER4", "INPUT_DRIVERPERSONNUMBER5"};
        }

        public static class Input_SprayerPersonNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"008783159\" INTO Input_SprayerPersonNumber
            public static String HINT = "TYPE \"008783159\" INTO Input_SprayerPersonNumber";

            public static final By INPUT_SPRAYERPERSONNUMBER1 = By.xpath("//*[contains(@resource-id,'Input_SprayerPersonNumber')]");
            public static final By INPUT_SPRAYERPERSONNUMBER2 = By.xpath("//*[@resource-id='Input_SprayerPersonNumber']");
            public static final By INPUT_SPRAYERPERSONNUMBER3 = By.xpath("//*[@resource-id='Input_SprayerPersonNumber']");
            public static final By INPUT_SPRAYERPERSONNUMBER4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_SPRAYERPERSONNUMBER1", "INPUT_SPRAYERPERSONNUMBER2", "INPUT_SPRAYERPERSONNUMBER3", "INPUT_SPRAYERPERSONNUMBER4"};
        }

        public static class ContinueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Continue
            public static String HINT = "CLICK Continue";

            public static final By CONTINUE1 = By.xpath("//*[normalize-space(@text)='Continue']");
            public static final By CONTINUE2 = By.xpath("//android.widget.Button[@text='Continue']");

            public static final String[] FALLBACK_ORDER = new String[] {"CONTINUE1", "CONTINUE2"};
        }

    }

    public static class FluidTypeSelection {

        public static class LabelIVElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Add_Type_IV BEFORE
            public static String HINT = "CLICK Add_Type_IV BEFORE";

            public static final By LABELIV1 = By.xpath("//*[@resource-id='LabelIV']/preceding-sibling::*[1]");

            public static final String[] FALLBACK_ORDER = new String[] {"LABELIV1"};
        }

        public static class LabelElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Add_Type_I BEFORE
            public static String HINT = "CLICK Add_Type_I BEFORE";

            public static final By LABEL1 = By.xpath("//*[@resource-id='Label']/preceding-sibling::*[1]");

            public static final String[] FALLBACK_ORDER = new String[] {"LABEL1"};
        }

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACK1 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACK2 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACK1", "BACK2"};
        }

        public static class Checkbox1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CHECKBOX11 = By.xpath("//*[contains(@resource-id,'Checkbox1')]");
            public static final By CHECKBOX12 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX13 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX14 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX11", "CHECKBOX12", "CHECKBOX13", "CHECKBOX14"};
        }

        public static class ContinueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK CONTINUE
            public static String HINT = "CLICK CONTINUE";

            public static final By CONTINUE1 = By.xpath("//*[normalize-space(@text)='Continue']");
            public static final By CONTINUE2 = By.xpath("//android.widget.Button[@text='Continue']");

            public static final String[] FALLBACK_ORDER = new String[] {"CONTINUE1", "CONTINUE2"};
        }

        public static class EditElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By EDIT1 = By.className("android.view.View");

            public static final String[] FALLBACK_ORDER = new String[] {"EDIT1"};
        }

    }

    public static class LogDetails {

        public static class E_7__SlushElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Slush
            public static String HINT = "CLICK Slush";

            public static final By E_7__SLUSH1 = By.xpath("//*[normalize-space(@text)='7- Slush']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_7__SLUSH1"};
        }

        public static class Weather_Condition_Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Weather_Condition AFTER
            public static String HINT = "CLICK Weather_Condition AFTER";

            public static final By WEATHER_CONDITION_1 = By.xpath("//*[normalize-space(@text)='Weather Condition*']/following-sibling::*[1]");

            public static final String[] FALLBACK_ORDER = new String[] {"WEATHER_CONDITION_1"};
        }

        public static class type_INPUT_VDRIVERNUMBER3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"N068799\" INTO type_INPUT_VDRIVERNUMBER3
            public static String HINT = "TYPE \"N068799\" INTO type_INPUT_VDRIVERNUMBER3";

            public static final By TYPE_INPUT_VDRIVERNUMBER31 = By.xpath("//android.widget.EditText[@resource-id='Input_VDriverNumber3']");

            public static final String[] FALLBACK_ORDER = new String[] {"TYPE_INPUT_VDRIVERNUMBER31"};
        }

        public static class click_INPUT_VDRIVERNUMBER3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK click_INPUT_VDRIVERNUMBER3
            public static String HINT = "CLICK click_INPUT_VDRIVERNUMBER3";

            public static final By CLICK_INPUT_VDRIVERNUMBER31 = By.xpath("//android.widget.EditText[@resource-id='Input_VDriverNumber3']");

            public static final String[] FALLBACK_ORDER = new String[] {"CLICK_INPUT_VDRIVERNUMBER31"};
        }

        public static class _UA__United_AirlinesElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK UNITED_AIRLINES
            public static String HINT = "CLICK UNITED_AIRLINES";

            public static final By _UA__UNITED_AIRLINES1 = By.xpath("//*[normalize-space(@text)='(UA) United Airlines']");

            public static final String[] FALLBACK_ORDER = new String[] {"_UA__UNITED_AIRLINES1"};
        }

        public static class Customer_Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Customer AFTER
            public static String HINT = "CLICK Customer AFTER";

            public static final By CUSTOMER_1 = By.xpath("//*[normalize-space(@text)='Customer*']/following-sibling::*[1]");

            public static final String[] FALLBACK_ORDER = new String[] {"CUSTOMER_1"};
        }

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACK1 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACK2 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACK1", "BACK2"};
        }

        public static class Vscomp_ele_wrapper_1801Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By VSCOMP_ELE_WRAPPER_18011 = By.xpath("//*[contains(@resource-id,'vscomp-ele-wrapper-1801')]");
            public static final By VSCOMP_ELE_WRAPPER_18012 = By.xpath("//*[@resource-id='vscomp-ele-wrapper-1801']");
            public static final By VSCOMP_ELE_WRAPPER_18013 = By.xpath("//*[@resource-id='vscomp-ele-wrapper-1801']");
            public static final By VSCOMP_ELE_WRAPPER_18014 = By.xpath("//*[normalize-space(@text)='Select flight number or click one from suggestion below ']");
            public static final By VSCOMP_ELE_WRAPPER_18015 = By.xpath("//android.widget.Spinner[@text='Select flight number or click one from suggestion below ']");

            public static final String[] FALLBACK_ORDER = new String[] {"VSCOMP_ELE_WRAPPER_18011", "VSCOMP_ELE_WRAPPER_18012", "VSCOMP_ELE_WRAPPER_18013", "VSCOMP_ELE_WRAPPER_18014", "VSCOMP_ELE_WRAPPER_18015"};
        }

        public static class Yes_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By YES_INPUT1 = By.xpath("//*[contains(@resource-id,'Yes-input')]");
            public static final By YES_INPUT2 = By.xpath("//*[@resource-id='Yes-input']");
            public static final By YES_INPUT3 = By.xpath("//*[@resource-id='Yes-input']");
            public static final By YES_INPUT4 = By.xpath("//*[normalize-space(@text)='Yes']");
            public static final By YES_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Yes']");

            public static final String[] FALLBACK_ORDER = new String[] {"YES_INPUT1", "YES_INPUT2", "YES_INPUT3", "YES_INPUT4", "YES_INPUT5"};
        }

        public static class No_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK No_input
            public static String HINT = "CLICK No_input";

            public static final By NO_INPUT1 = By.xpath("//*[contains(@resource-id,'No-input')]");
            public static final By NO_INPUT2 = By.xpath("//*[@resource-id='No-input']");
            public static final By NO_INPUT3 = By.xpath("//*[@resource-id='No-input']");
            public static final By NO_INPUT4 = By.xpath("//*[normalize-space(@text)='No']");
            public static final By NO_INPUT5 = By.xpath("//android.widget.RadioButton[@text='No']");

            public static final String[] FALLBACK_ORDER = new String[] {"NO_INPUT1", "NO_INPUT2", "NO_INPUT3", "NO_INPUT4", "NO_INPUT5"};
        }

        public static class Vscomp_ele_wrapper_5435Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By VSCOMP_ELE_WRAPPER_54351 = By.xpath("//*[contains(@resource-id,'vscomp-ele-wrapper-5435')]");
            public static final By VSCOMP_ELE_WRAPPER_54352 = By.xpath("//*[@resource-id='vscomp-ele-wrapper-5435']");
            public static final By VSCOMP_ELE_WRAPPER_54353 = By.xpath("//*[@resource-id='vscomp-ele-wrapper-5435']");
            public static final By VSCOMP_ELE_WRAPPER_54354 = By.xpath("//*[normalize-space(@text)='Select aircraft registration number or click one from suggestion below ']");
            public static final By VSCOMP_ELE_WRAPPER_54355 = By.xpath("//android.widget.Spinner[@text='Select aircraft registration number or click one from suggestion below ']");

            public static final String[] FALLBACK_ORDER = new String[] {"VSCOMP_ELE_WRAPPER_54351", "VSCOMP_ELE_WRAPPER_54352", "VSCOMP_ELE_WRAPPER_54353", "VSCOMP_ELE_WRAPPER_54354", "VSCOMP_ELE_WRAPPER_54355"};
        }

        public static class RegFound_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By REGFOUND_INPUT1 = By.xpath("//*[contains(@resource-id,'RegFound-input')]");
            public static final By REGFOUND_INPUT2 = By.xpath("//*[@resource-id='RegFound-input']");
            public static final By REGFOUND_INPUT3 = By.xpath("//*[@resource-id='RegFound-input']");
            public static final By REGFOUND_INPUT4 = By.xpath("//*[normalize-space(@text)='Yes']");
            public static final By REGFOUND_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Yes']");

            public static final String[] FALLBACK_ORDER = new String[] {"REGFOUND_INPUT1", "REGFOUND_INPUT2", "REGFOUND_INPUT3", "REGFOUND_INPUT4", "REGFOUND_INPUT5"};
        }

        public static class RegNotFount_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK RegNotFount_input
            public static String HINT = "CLICK RegNotFount_input";

            public static final By REGNOTFOUNT_INPUT1 = By.xpath("//*[contains(@resource-id,'RegNotFount-input')]");
            public static final By REGNOTFOUNT_INPUT2 = By.xpath("//*[@resource-id='RegNotFount-input']");
            public static final By REGNOTFOUNT_INPUT3 = By.xpath("//*[@resource-id='RegNotFount-input']");
            public static final By REGNOTFOUNT_INPUT4 = By.xpath("//*[normalize-space(@text)='No']");
            public static final By REGNOTFOUNT_INPUT5 = By.xpath("//android.widget.RadioButton[@text='No']");

            public static final String[] FALLBACK_ORDER = new String[] {"REGNOTFOUNT_INPUT1", "REGNOTFOUNT_INPUT2", "REGNOTFOUNT_INPUT3", "REGNOTFOUNT_INPUT4", "REGNOTFOUNT_INPUT5"};
        }

        public static class Input_AircraftShipNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST\" INTO Input_AircraftShipNumber
            public static String HINT = "TYPE \"TEST\" INTO Input_AircraftShipNumber";

            public static final By INPUT_AIRCRAFTSHIPNUMBER1 = By.xpath("//*[contains(@resource-id,'Input_AircraftShipNumber')]");
            public static final By INPUT_AIRCRAFTSHIPNUMBER2 = By.xpath("//*[@resource-id='Input_AircraftShipNumber']");
            public static final By INPUT_AIRCRAFTSHIPNUMBER3 = By.xpath("//*[@resource-id='Input_AircraftShipNumber']");
            public static final By INPUT_AIRCRAFTSHIPNUMBER4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_AIRCRAFTSHIPNUMBER1", "INPUT_AIRCRAFTSHIPNUMBER2", "INPUT_AIRCRAFTSHIPNUMBER3", "INPUT_AIRCRAFTSHIPNUMBER4"};
        }

        public static class Input_AircraftLocationElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST AIR LOCATION\" INTO Input_AircraftLocation
            public static String HINT = "TYPE \"TEST AIR LOCATION\" INTO Input_AircraftLocation";

            public static final By INPUT_AIRCRAFTLOCATION1 = By.xpath("//*[contains(@resource-id,'Input_AircraftLocation')]");
            public static final By INPUT_AIRCRAFTLOCATION2 = By.xpath("//*[@resource-id='Input_AircraftLocation']");
            public static final By INPUT_AIRCRAFTLOCATION3 = By.xpath("//*[@resource-id='Input_AircraftLocation']");
            public static final By INPUT_AIRCRAFTLOCATION4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_AIRCRAFTLOCATION1", "INPUT_AIRCRAFTLOCATION2", "INPUT_AIRCRAFTLOCATION3", "INPUT_AIRCRAFTLOCATION4"};
        }

        public static class Input_VDriverNumber3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_VDRIVERNUMBER31 = By.xpath("//*[contains(@resource-id,'Input_VDriverNumber3')]");
            public static final By INPUT_VDRIVERNUMBER32 = By.xpath("//*[@resource-id='Input_VDriverNumber3']");
            public static final By INPUT_VDRIVERNUMBER33 = By.xpath("//*[@resource-id='Input_VDriverNumber3']");
            public static final By INPUT_VDRIVERNUMBER34 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_VDRIVERNUMBER31", "INPUT_VDRIVERNUMBER32", "INPUT_VDRIVERNUMBER33", "INPUT_VDRIVERNUMBER34"};
        }

        public static class Input_VSprayerrNumber3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"A000743\" INTO Input_VSprayerrNumber3
            public static String HINT = "TYPE \"A000743\" INTO Input_VSprayerrNumber3";

            public static final By INPUT_VSPRAYERRNUMBER31 = By.xpath("//*[contains(@resource-id,'Input_VSprayerrNumber3')]");
            public static final By INPUT_VSPRAYERRNUMBER32 = By.xpath("//*[@resource-id='Input_VSprayerrNumber3']");
            public static final By INPUT_VSPRAYERRNUMBER33 = By.xpath("//*[@resource-id='Input_VSprayerrNumber3']");
            public static final By INPUT_VSPRAYERRNUMBER34 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_VSPRAYERRNUMBER31", "INPUT_VSPRAYERRNUMBER32", "INPUT_VSPRAYERRNUMBER33", "INPUT_VSPRAYERRNUMBER34"};
        }

        public static class CheckElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK CHECK
            public static String HINT = "CLICK CHECK";

            public static final By CHECK1 = By.xpath("//*[normalize-space(@text)='Check']");
            public static final By CHECK2 = By.xpath("//android.widget.Button[@text='Check']");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECK1", "CHECK2"};
        }

        public static class Input_FlightNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"DL TEST FN\" INTO Input_FlightNumber
            public static String HINT = "TYPE \"DL TEST FN\" INTO Input_FlightNumber";

            public static final By INPUT_FLIGHTNUMBER1 = By.xpath("//*[contains(@resource-id,'Input_FlightNumber')]");
            public static final By INPUT_FLIGHTNUMBER2 = By.xpath("//*[@resource-id='Input_FlightNumber']");
            public static final By INPUT_FLIGHTNUMBER3 = By.xpath("//*[@resource-id='Input_FlightNumber']");
            public static final By INPUT_FLIGHTNUMBER4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLIGHTNUMBER1", "INPUT_FLIGHTNUMBER2", "INPUT_FLIGHTNUMBER3", "INPUT_FLIGHTNUMBER4"};
        }

        public static class Input_AircraftRegistrationNumberElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"DL TEST ARN\" INTO Input_AircraftRegistrationNumber
            public static String HINT = "TYPE \"DL TEST ARN\" INTO Input_AircraftRegistrationNumber";

            public static final By INPUT_AIRCRAFTREGISTRATIONNUMBER1 = By.xpath("//*[contains(@resource-id,'Input_AircraftRegistrationNumber')]");
            public static final By INPUT_AIRCRAFTREGISTRATIONNUMBER2 = By.xpath("//*[@resource-id='Input_AircraftRegistrationNumber']");
            public static final By INPUT_AIRCRAFTREGISTRATIONNUMBER3 = By.xpath("//*[@resource-id='Input_AircraftRegistrationNumber']");
            public static final By INPUT_AIRCRAFTREGISTRATIONNUMBER4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_AIRCRAFTREGISTRATIONNUMBER1", "INPUT_AIRCRAFTREGISTRATIONNUMBER2", "INPUT_AIRCRAFTREGISTRATIONNUMBER3", "INPUT_AIRCRAFTREGISTRATIONNUMBER4"};
        }

        public static class Input_OutdoorAirTemperatureElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Input_OutdoorAirTemperature
            public static String HINT = "CLICK Input_OutdoorAirTemperature";

            public static final By INPUT_OUTDOORAIRTEMPERATURE1 = By.xpath("//*[contains(@resource-id,'Input_OutdoorAirTemperature')]");
            public static final By INPUT_OUTDOORAIRTEMPERATURE2 = By.xpath("//*[@resource-id='Input_OutdoorAirTemperature']");
            public static final By INPUT_OUTDOORAIRTEMPERATURE3 = By.xpath("//*[@resource-id='Input_OutdoorAirTemperature']");
            public static final By INPUT_OUTDOORAIRTEMPERATURE4 = By.xpath("//*[normalize-space(@text)='OAT (C°) (Read from ATIS)*']");
            public static final By INPUT_OUTDOORAIRTEMPERATURE5 = By.xpath("//android.widget.EditText[@text='OAT (C°) (Read from ATIS)*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_OUTDOORAIRTEMPERATURE1", "INPUT_OUTDOORAIRTEMPERATURE2", "INPUT_OUTDOORAIRTEMPERATURE3", "INPUT_OUTDOORAIRTEMPERATURE4", "INPUT_OUTDOORAIRTEMPERATURE5"};
        }

        public static class Checkbox3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK Checkbox3
            public static String HINT = "CLICK Checkbox3";

            public static final By CHECKBOX31 = By.xpath("//*[contains(@resource-id,'Checkbox3')]");
            public static final By CHECKBOX32 = By.xpath("//*[@resource-id='Checkbox3']");
            public static final By CHECKBOX33 = By.xpath("//*[@resource-id='Checkbox3']");
            public static final By CHECKBOX34 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX31", "CHECKBOX32", "CHECKBOX33", "CHECKBOX34"};
        }

        public static class HIDElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST\" INTO HID
            public static String HINT = "TYPE \"TEST\" INTO HID";

            public static final By HID1 = By.xpath("//*[contains(@resource-id,'HID')]");
            public static final By HID2 = By.xpath("//*[@resource-id='HID']");
            public static final By HID3 = By.xpath("//*[@resource-id='HID']");
            public static final By HID4 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"HID1", "HID2", "HID3", "HID4"};
        }

        public static class HID2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: TYPE \"TEST\" INTO HID2
            public static String HINT = "TYPE \"TEST\" INTO HID2";

            public static final By HID21 = By.xpath("//*[contains(@resource-id,'HID2')]");
            public static final By HID22 = By.xpath("//*[@resource-id='HID2']");
            public static final By HID23 = By.xpath("//*[@resource-id='HID2']");
            public static final By HID24 = By.className("android.widget.EditText");

            public static final String[] FALLBACK_ORDER = new String[] {"HID21", "HID22", "HID23", "HID24"};
        }

        public static class Checkbox1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CHECKBOX11 = By.xpath("//*[contains(@resource-id,'Checkbox1')]");
            public static final By CHECKBOX12 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX13 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX14 = By.xpath("//*[normalize-space(@text)='I have inspected the vehicle / completed POI*']");
            public static final By CHECKBOX15 = By.xpath("//android.widget.CheckBox[@text='I have inspected the vehicle / completed POI*']");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX11", "CHECKBOX12", "CHECKBOX13", "CHECKBOX14", "CHECKBOX15"};
        }

        public static class Checkbox2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CHECKBOX21 = By.xpath("//*[contains(@resource-id,'Checkbox2')]");
            public static final By CHECKBOX22 = By.xpath("//*[@resource-id='Checkbox2']");
            public static final By CHECKBOX23 = By.xpath("//*[@resource-id='Checkbox2']");
            public static final By CHECKBOX24 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX21", "CHECKBOX22", "CHECKBOX23", "CHECKBOX24"};
        }

        public static class ContinueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK CONTINUE
            public static String HINT = "CLICK CONTINUE";

            public static final By CONTINUE1 = By.xpath("//*[normalize-space(@text)='Continue']");
            public static final By CONTINUE2 = By.xpath("//android.widget.Button[@text='Continue']");

            public static final String[] FALLBACK_ORDER = new String[] {"CONTINUE1", "CONTINUE2"};
        }

    }

    public static class TypeIFluidApplication {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACK1 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACK2 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACK1", "BACK2"};
        }

        public static class ButtonGroupItem1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK Type_I_Used
            public static String HINT = "CLICK Type_I_Used";

            public static final By BUTTONGROUPITEM11 = By.xpath("//*[contains(@resource-id,'ButtonGroupItem1')]");
            public static final By BUTTONGROUPITEM12 = By.xpath("//*[@resource-id='ButtonGroupItem1']");
            public static final By BUTTONGROUPITEM13 = By.xpath("//*[@resource-id='ButtonGroupItem1']");
            public static final By BUTTONGROUPITEM14 = By.xpath("//*[normalize-space(@text)='Type I Used']");
            public static final By BUTTONGROUPITEM15 = By.xpath("//android.widget.RadioButton[@text='Type I Used']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTONGROUPITEM11", "BUTTONGROUPITEM12", "BUTTONGROUPITEM13", "BUTTONGROUPITEM14", "BUTTONGROUPITEM15"};
        }

        public static class ButtonGroupItem2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTONGROUPITEM21 = By.xpath("//*[contains(@resource-id,'ButtonGroupItem2')]");
            public static final By BUTTONGROUPITEM22 = By.xpath("//*[@resource-id='ButtonGroupItem2']");
            public static final By BUTTONGROUPITEM23 = By.xpath("//*[@resource-id='ButtonGroupItem2']");
            public static final By BUTTONGROUPITEM24 = By.xpath("//*[normalize-space(@text)='Type I Not Used']");
            public static final By BUTTONGROUPITEM25 = By.xpath("//android.widget.RadioButton[@text='Type I Not Used']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTONGROUPITEM21", "BUTTONGROUPITEM22", "BUTTONGROUPITEM23", "BUTTONGROUPITEM24", "BUTTONGROUPITEM25"};
        }

        public static class Input_FluidTypeI_StartDateTimeElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Input_FluidTypeI_StartDateTime
            public static String HINT = "CLICK Input_FluidTypeI_StartDateTime";

            public static final By INPUT_FLUIDTYPEI_STARTDATETIME1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_StartDateTime')]");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME2 = By.xpath("//*[@resource-id='Input_FluidTypeI_StartDateTime']");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME3 = By.xpath("//*[@resource-id='Input_FluidTypeI_StartDateTime']");
            public static final By INPUT_FLUIDTYPEI_STARTDATETIME4 = By.className("android.widget.Spinner");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_STARTDATETIME1", "INPUT_FLUIDTYPEI_STARTDATETIME2", "INPUT_FLUIDTYPEI_STARTDATETIME3", "INPUT_FLUIDTYPEI_STARTDATETIME4"};
        }

        public static class Input_FluidTypeI_EndDateTimeElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Input_FluidTypeI_EndDateTime
            public static String HINT = "CLICK Input_FluidTypeI_EndDateTime";

            public static final By INPUT_FLUIDTYPEI_ENDDATETIME1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_EndDateTime')]");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME2 = By.xpath("//*[@resource-id='Input_FluidTypeI_EndDateTime']");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME3 = By.xpath("//*[@resource-id='Input_FluidTypeI_EndDateTime']");
            public static final By INPUT_FLUIDTYPEI_ENDDATETIME4 = By.className("android.widget.Spinner");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_ENDDATETIME1", "INPUT_FLUIDTYPEI_ENDDATETIME2", "INPUT_FLUIDTYPEI_ENDDATETIME3", "INPUT_FLUIDTYPEI_ENDDATETIME4"};
        }

        public static class Input_FluidTypeI_GallonsUsedElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Type_I_Gallons_Applied
            public static String HINT = "CLICK Type_I_Gallons_Applied";

            public static final By INPUT_FLUIDTYPEI_GALLONSUSED1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_GallonsUsed')]");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED2 = By.xpath("//*[@resource-id='Input_FluidTypeI_GallonsUsed']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED3 = By.xpath("//*[@resource-id='Input_FluidTypeI_GallonsUsed']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED4 = By.xpath("//*[normalize-space(@text)='Type I Gallons Applied*']");
            public static final By INPUT_FLUIDTYPEI_GALLONSUSED5 = By.xpath("//android.widget.EditText[@text='Type I Gallons Applied*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_GALLONSUSED1", "INPUT_FLUIDTYPEI_GALLONSUSED2", "INPUT_FLUIDTYPEI_GALLONSUSED3", "INPUT_FLUIDTYPEI_GALLONSUSED4", "INPUT_FLUIDTYPEI_GALLONSUSED5"};
        }

        public static class Checkbox1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By CHECKBOX11 = By.xpath("//*[contains(@resource-id,'Checkbox1')]");
            public static final By CHECKBOX12 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX13 = By.xpath("//*[@resource-id='Checkbox1']");
            public static final By CHECKBOX14 = By.xpath("//*[normalize-space(@text)='Read from meter']");
            public static final By CHECKBOX15 = By.xpath("//android.widget.CheckBox[@text='Read from meter']");

            public static final String[] FALLBACK_ORDER = new String[] {"CHECKBOX11", "CHECKBOX12", "CHECKBOX13", "CHECKBOX14", "CHECKBOX15"};
        }

        public static class Input_FluidTypeI_ProductValueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEI_PRODUCTVALUE1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_ProductValue')]");
            public static final By INPUT_FLUIDTYPEI_PRODUCTVALUE2 = By.xpath("//*[@resource-id='Input_FluidTypeI_ProductValue']");
            public static final By INPUT_FLUIDTYPEI_PRODUCTVALUE3 = By.xpath("//*[@resource-id='Input_FluidTypeI_ProductValue']");
            public static final By INPUT_FLUIDTYPEI_PRODUCTVALUE4 = By.xpath("//*[normalize-space(@text)='DOW UCAR PG ADF']");
            public static final By INPUT_FLUIDTYPEI_PRODUCTVALUE5 = By.xpath("//android.widget.EditText[@text='DOW UCAR PG ADF']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_PRODUCTVALUE1", "INPUT_FLUIDTYPEI_PRODUCTVALUE2", "INPUT_FLUIDTYPEI_PRODUCTVALUE3", "INPUT_FLUIDTYPEI_PRODUCTVALUE4", "INPUT_FLUIDTYPEI_PRODUCTVALUE5"};
        }

        public static class Input_FluidTypeI_DilutionElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEI_DILUTION1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_Dilution')]");
            public static final By INPUT_FLUIDTYPEI_DILUTION2 = By.xpath("//*[@resource-id='Input_FluidTypeI_Dilution']");
            public static final By INPUT_FLUIDTYPEI_DILUTION3 = By.xpath("//*[@resource-id='Input_FluidTypeI_Dilution']");
            public static final By INPUT_FLUIDTYPEI_DILUTION4 = By.xpath("//*[normalize-space(@text)='30, Type I Glycol Dilution']");
            public static final By INPUT_FLUIDTYPEI_DILUTION5 = By.xpath("//android.widget.EditText[@text='30, Type I Glycol Dilution']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_DILUTION1", "INPUT_FLUIDTYPEI_DILUTION2", "INPUT_FLUIDTYPEI_DILUTION3", "INPUT_FLUIDTYPEI_DILUTION4", "INPUT_FLUIDTYPEI_DILUTION5"};
        }

        public static class E_56Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_561 = By.xpath("//*[normalize-space(@text)='56']");
            public static final By E_562 = By.xpath("//android.widget.Button[@text='56']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_561", "E_562"};
        }

        public static class E_58Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By E_581 = By.xpath("//*[normalize-space(@text)='58']");
            public static final By E_582 = By.xpath("//android.widget.Button[@text='58']");

            public static final String[] FALLBACK_ORDER = new String[] {"E_581", "E_582"};
        }

        public static class Button3Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTON31 = By.xpath("//*[contains(@resource-id,'android:id/button3')]");
            public static final By BUTTON32 = By.xpath("//*[@resource-id='android:id/button3']");
            public static final By BUTTON33 = By.xpath("//*[@resource-id='android:id/button3']");
            public static final By BUTTON34 = By.xpath("//*[normalize-space(@text)='CLEAR']");
            public static final By BUTTON35 = By.xpath("//android.widget.Button[@text='CLEAR']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON31", "BUTTON32", "BUTTON33", "BUTTON34", "BUTTON35"};
        }

        public static class Button2Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTON21 = By.xpath("//*[contains(@resource-id,'android:id/button2')]");
            public static final By BUTTON22 = By.xpath("//*[@resource-id='android:id/button2']");
            public static final By BUTTON23 = By.xpath("//*[@resource-id='android:id/button2']");
            public static final By BUTTON24 = By.xpath("//*[normalize-space(@text)='CANCEL']");
            public static final By BUTTON25 = By.xpath("//android.widget.Button[@text='CANCEL']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON21", "BUTTON22", "BUTTON23", "BUTTON24", "BUTTON25"};
        }

        public static class Button1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SET
            public static String HINT = "CLICK SET";

            public static final By BUTTON11 = By.xpath("//*[contains(@resource-id,'android:id/button1')]");
            public static final By BUTTON12 = By.xpath("//*[@resource-id='android:id/button1']");
            public static final By BUTTON13 = By.xpath("//*[@resource-id='android:id/button1']");
            public static final By BUTTON14 = By.xpath("//*[normalize-space(@text)='SET']");
            public static final By BUTTON15 = By.xpath("//android.widget.Button[@text='SET']");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON11", "BUTTON12", "BUTTON13", "BUTTON14", "BUTTON15"};
        }

        public static class Input_FluidTypeI_FreezePointElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = true;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT1 = By.xpath("//*[contains(@resource-id,'Input_FluidTypeI_FreezePoint')]");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT2 = By.xpath("//*[@resource-id='Input_FluidTypeI_FreezePoint']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT3 = By.xpath("//*[@resource-id='Input_FluidTypeI_FreezePoint']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT4 = By.xpath("//*[normalize-space(@text)='-10, Type I Freeze Point (°C)*']");
            public static final By INPUT_FLUIDTYPEI_FREEZEPOINT5 = By.xpath("//android.widget.EditText[@text='-10, Type I Freeze Point (°C)*']");

            public static final String[] FALLBACK_ORDER = new String[] {"INPUT_FLUIDTYPEI_FREEZEPOINT1", "INPUT_FLUIDTYPEI_FREEZEPOINT2", "INPUT_FLUIDTYPEI_FREEZEPOINT3", "INPUT_FLUIDTYPEI_FREEZEPOINT4", "INPUT_FLUIDTYPEI_FREEZEPOINT5"};
        }

        public static class SaveElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK SAVE
            public static String HINT = "CLICK SAVE";

            public static final By SAVE1 = By.xpath("//*[normalize-space(@text)='Save']");
            public static final By SAVE2 = By.xpath("//android.widget.Button[@text='Save']");

            public static final String[] FALLBACK_ORDER = new String[] {"SAVE1", "SAVE2"};
        }

    }

    public static class PreviewScreen {

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class Truck_InformationElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK TRUCK_INFORMATION_BUTTON
            public static String HINT = "CLICK TRUCK_INFORMATION_BUTTON";

            public static final By TRUCK_INFORMATION1 = By.xpath("//*[normalize-space(@text)='Truck Information']");
            public static final By TRUCK_INFORMATION2 = By.xpath("//android.widget.Button[@text='Truck Information']");

            public static final String[] FALLBACK_ORDER = new String[] {"TRUCK_INFORMATION1", "TRUCK_INFORMATION2"};
        }

        public static class Start_New_LogElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK Start_New_Log
            public static String HINT = "CLICK Start_New_Log";

            public static final By START_NEW_LOG1 = By.xpath("//*[normalize-space(@text)='Start New Log']");
            public static final By START_NEW_LOG2 = By.xpath("//android.widget.Button[@text='Start New Log']");

            public static final String[] FALLBACK_ORDER = new String[] {"START_NEW_LOG1", "START_NEW_LOG2"};
        }

    }

    public static class FluidApplication {

        public static class RadioButton1_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: CLICK Entire_Aircraft BEFORE
            public static String HINT = "CLICK Entire_Aircraft BEFORE";

            public static final By RADIOBUTTON1_INPUT1 = By.xpath("//*[@resource-id='RadioButton1-input']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON1_INPUT1"};
        }

        public static class Toggle_the_MenuElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By TOGGLE_THE_MENU1 = By.xpath("//*[normalize-space(@text)='Toggle the Menu']");
            public static final By TOGGLE_THE_MENU2 = By.xpath("//android.widget.Button[@text='Toggle the Menu']");

            public static final String[] FALLBACK_ORDER = new String[] {"TOGGLE_THE_MENU1", "TOGGLE_THE_MENU2"};
        }

        public static class BackElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BACK1 = By.xpath("//*[normalize-space(@text)='Back']");
            public static final By BACK2 = By.xpath("//android.widget.Button[@text='Back']");

            public static final String[] FALLBACK_ORDER = new String[] {"BACK1", "BACK2"};
        }

        public static class RadioButton4_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON4_INPUT1 = By.xpath("//*[contains(@resource-id,'RadioButton4-input')]");
            public static final By RADIOBUTTON4_INPUT2 = By.xpath("//*[@resource-id='RadioButton4-input']");
            public static final By RADIOBUTTON4_INPUT3 = By.xpath("//*[@resource-id='RadioButton4-input']");
            public static final By RADIOBUTTON4_INPUT4 = By.xpath("//*[normalize-space(@text)='Wings and Tail Only']");
            public static final By RADIOBUTTON4_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Wings and Tail Only']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON4_INPUT1", "RADIOBUTTON4_INPUT2", "RADIOBUTTON4_INPUT3", "RADIOBUTTON4_INPUT4", "RADIOBUTTON4_INPUT5"};
        }

        public static class RadioButton1_inputElement_2 {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON1_INPUT1 = By.xpath("//*[normalize-space(@text)='Entire Aircraft']");
            public static final By RADIOBUTTON1_INPUT2 = By.xpath("//*[contains(@resource-id,'RadioButton1-input')]");
            public static final By RADIOBUTTON1_INPUT3 = By.xpath("//*[@resource-id='RadioButton1-input']");
            public static final By RADIOBUTTON1_INPUT4 = By.xpath("//*[@resource-id='RadioButton1-input']");
            public static final By RADIOBUTTON1_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Entire Aircraft']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON1_INPUT1", "RADIOBUTTON1_INPUT2", "RADIOBUTTON1_INPUT3", "RADIOBUTTON1_INPUT4", "RADIOBUTTON1_INPUT5"};
        }

        public static class RadioButton2_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON2_INPUT1 = By.xpath("//*[contains(@resource-id,'RadioButton2-input')]");
            public static final By RADIOBUTTON2_INPUT2 = By.xpath("//*[@resource-id='RadioButton2-input']");
            public static final By RADIOBUTTON2_INPUT3 = By.xpath("//*[@resource-id='RadioButton2-input']");
            public static final By RADIOBUTTON2_INPUT4 = By.xpath("//*[normalize-space(@text)='Multi-truck Left Aircraft (Captain Side)']");
            public static final By RADIOBUTTON2_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Multi-truck Left Aircraft (Captain Side)']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON2_INPUT1", "RADIOBUTTON2_INPUT2", "RADIOBUTTON2_INPUT3", "RADIOBUTTON2_INPUT4", "RADIOBUTTON2_INPUT5"};
        }

        public static class RadioButton3_inputElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By RADIOBUTTON3_INPUT1 = By.xpath("//*[contains(@resource-id,'RadioButton3-input')]");
            public static final By RADIOBUTTON3_INPUT2 = By.xpath("//*[@resource-id='RadioButton3-input']");
            public static final By RADIOBUTTON3_INPUT3 = By.xpath("//*[@resource-id='RadioButton3-input']");
            public static final By RADIOBUTTON3_INPUT4 = By.xpath("//*[normalize-space(@text)='Multi-truck Right Aircraft (First Officer Side)']");
            public static final By RADIOBUTTON3_INPUT5 = By.xpath("//android.widget.RadioButton[@text='Multi-truck Right Aircraft (First Officer Side)']");

            public static final String[] FALLBACK_ORDER = new String[] {"RADIOBUTTON3_INPUT1", "RADIOBUTTON3_INPUT2", "RADIOBUTTON3_INPUT3", "RADIOBUTTON3_INPUT4", "RADIOBUTTON3_INPUT5"};
        }

        public static class InspectionOnlyCheckBoxElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = true;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By INSPECTIONONLYCHECKBOX1 = By.xpath("//*[contains(@resource-id,'InspectionOnlyCheckBox')]");
            public static final By INSPECTIONONLYCHECKBOX2 = By.xpath("//*[@resource-id='InspectionOnlyCheckBox']");
            public static final By INSPECTIONONLYCHECKBOX3 = By.xpath("//*[@resource-id='InspectionOnlyCheckBox']");
            public static final By INSPECTIONONLYCHECKBOX4 = By.className("android.widget.CheckBox");

            public static final String[] FALLBACK_ORDER = new String[] {"INSPECTIONONLYCHECKBOX1", "INSPECTIONONLYCHECKBOX2", "INSPECTIONONLYCHECKBOX3", "INSPECTIONONLYCHECKBOX4"};
        }

        public static class ContinueElement {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: CLICK CONTINUE
            public static String HINT = "CLICK CONTINUE";

            public static final By CONTINUE1 = By.xpath("//*[normalize-space(@text)='Continue']");
            public static final By CONTINUE2 = By.xpath("//android.widget.Button[@text='Continue']");

            public static final String[] FALLBACK_ORDER = new String[] {"CONTINUE1", "CONTINUE2"};
        }

        public static class Button_1Element {
            public static final boolean CLICKABLE = true;
            public static final boolean TYPABLE = false;
            public static final boolean CHECKABLE = false;

            // hint: BDD Statement
            public static String HINT = "BDD Statement";

            public static final By BUTTON_11 = By.className("android.widget.Button");

            public static final String[] FALLBACK_ORDER = new String[] {"BUTTON_11"};
        }

    }

}
