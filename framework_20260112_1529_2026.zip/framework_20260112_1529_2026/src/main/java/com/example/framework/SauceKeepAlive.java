package com.example.framework;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Helper for sending tiny no-op commands so that the Sauce Labs
 * session does not get closed due to inactivity.
 */
public class SauceKeepAlive {

    private SauceKeepAlive() { }

    /**
     * Fire a very cheap no-op call on the driver.
     */
    public static void ping(WebDriver driver) {
    	try {
    	    if (driver != null) {
    	        if (driver instanceof RemoteWebDriver) {
    	            ((RemoteWebDriver) driver).getCapabilities();  // <-- the ping
    	           System.out.println("[KeepAlive] Ping sent to Sauce Labs");
    	          // System.out.println(driver.getPageSource());
    	        } else {
    	            // Fallback ping for non-remote drivers
    	            driver.toString();
    	        }
    	    } else {
    	        System.out.println("[KeepAlive] Driver is null, skipping ping");
    	    }
    	} catch (Exception e) {
    	    System.out.println("[KeepAlive] Error: " + e.getMessage());
    	}

    }
}
