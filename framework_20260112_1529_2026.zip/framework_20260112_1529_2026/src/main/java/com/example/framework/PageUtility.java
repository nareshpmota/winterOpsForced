package com.example.framework;

import org.openqa.selenium.WebDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import java.time.Duration;
import java.util.Collections;


/**
 * Utility class that:
 *  1) uses PageMethods (fallback locators from PageObject)
 *  2) if all fail, calls SelfHealingLocator to use LLM on current page
 */
public class PageUtility {

    private PageUtility() {}

    public static void sendTextWithSelfHealing(
            WebDriver driver,
            Class<?> elementClass,
            String logicalName,
            String text
    ) {
        try {
            PageMethods.type(driver, elementClass, text);
        } catch (RuntimeException ex) {
            System.out.println("[SelfHeal] Normal fallback (original locators) failed for "
                    + logicalName + " (" + elementClass.getSimpleName()
                    + "). Taking LLM help for self-healing...");
            SelfHealingLocator.healAndType(driver, elementClass, logicalName, text, ex);
        }
    }

    public static void clickWithSelfHealing(
            WebDriver driver,
            Class<?> elementClass,
            String logicalName
    ) {
        try {
            PageMethods.click(driver, elementClass);
        } catch (RuntimeException ex) {
            System.out.println("[SelfHeal] Normal fallback (original locators) failed for "
                    + logicalName + " (" + elementClass.getSimpleName()
                    + "). Taking LLM help for self-healing...");
            SelfHealingLocator.healAndClick(driver, elementClass, logicalName, ex);
        }
    }
    // =========================================================
    //  COMMON KEY_TAP / KEY_TAP_ENTER / KEY_TAP_CLOSE HELPERS
    // =========================================================

    public static void keyTap(WebDriver driver, String keySpec, String context) {
        System.out.println("[BDD] KEY_TAP \"" + keySpec + "\" [" + context + "]");

        if (!(driver instanceof AndroidDriver)) {
            System.out.println("[PageUtility] KEY_TAP ignored, driver is not AndroidDriver");
            return;
        }

        AndroidDriver android = (AndroidDriver) driver;
        AndroidKey key = mapKey(keySpec);

        if (key == null) {
            System.out.println("[PageUtility] KEY_TAP ignored, unknown key: " + keySpec);
            return;
        }

        android.pressKey(new KeyEvent(key));
    }

    public static void tapByGrid(AndroidDriver driver, int row, int col) {

        // 🔧 CONFIG — change ONLY these later
        int TOTAL_ROWS = 10;
        int TOTAL_COLS = 5;

        Dimension size = driver.manage().window().getSize();

        double cellWidth  = (double) size.width  / TOTAL_COLS;
        double cellHeight = (double) size.height / TOTAL_ROWS;

        int tapX = (int) ((col - 0.5) * cellWidth);
        int tapY = (int) ((row - 0.5) * cellHeight);

        System.out.println(
            "[GRID TAP] row=" + row + ", col=" + col +
            " -> (" + tapX + "," + tapY + ")"
        );

        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence tap = new Sequence(finger, 1);

        tap.addAction(finger.createPointerMove(
                Duration.ZERO,
                PointerInput.Origin.viewport(),
                tapX, tapY));
        tap.addAction(finger.createPointerDown(
                PointerInput.MouseButton.LEFT.asArg()));
        tap.addAction(finger.createPointerUp(
                PointerInput.MouseButton.LEFT.asArg()));

        driver.perform(Collections.singletonList(tap));
    }
    public static void keyTapEnter(WebDriver driver, String context) {
        System.out.println("[BDD] KEY_TAP \"ENTER\" [" + context + "]");
        if (driver instanceof AndroidDriver) {
            AndroidDriver android = (AndroidDriver) driver;
            android.pressKey(new KeyEvent(AndroidKey.ENTER));
        } else {
            System.out.println("[PageUtility] KEY_TAP ENTER ignored, driver is not AndroidDriver");
        }
    }

    public static void keyTapClose(WebDriver driver, String context) {
        System.out.println("[BDD] KEY_TAP_CLOSE [" + context + "]");
        if (driver instanceof AndroidDriver) {
            AndroidDriver android = (AndroidDriver) driver;
            try {
                android.hideKeyboard();
            } catch (Exception e) {
                // fallback: BACK
                try {
                    android.pressKey(new KeyEvent(AndroidKey.BACK));
                } catch (Exception ignored) { }
            }
        } else {
            System.out.println("[PageUtility] KEY_TAP_CLOSE ignored, driver is not AndroidDriver");
        }
    }

    /**
     * Map BDD key strings to AndroidKey.
     * Mirrors logic from BddRunner.mapKey: digits, '-', and letters A–Z.
     */
    private static AndroidKey mapKey(String keySpec) {
        if (keySpec == null) return null;
        String k = keySpec.trim().toUpperCase();

        if (k.equals("0")) return AndroidKey.DIGIT_0;
        if (k.equals("1")) return AndroidKey.DIGIT_1;
        if (k.equals("2")) return AndroidKey.DIGIT_2;
        if (k.equals("3")) return AndroidKey.DIGIT_3;
        if (k.equals("4")) return AndroidKey.DIGIT_4;
        if (k.equals("5")) return AndroidKey.DIGIT_5;
        if (k.equals("6")) return AndroidKey.DIGIT_6;
        if (k.equals("7")) return AndroidKey.DIGIT_7;
        if (k.equals("8")) return AndroidKey.DIGIT_8;
        if (k.equals("9")) return AndroidKey.DIGIT_9;
        if (k.equals("-")) return AndroidKey.MINUS;

        // 👉 NEW: support letters A–Z for KEY_TAP "A"/"B"/"E"/...
        if (k.length() == 1 && k.charAt(0) >= 'A' && k.charAt(0) <= 'Z') {
            try {
                return AndroidKey.valueOf(k);   // AndroidKey.A, AndroidKey.B, ...
            } catch (IllegalArgumentException ignored) {
            }
        }

        switch (k) {
            case "ENTER": return AndroidKey.ENTER;
            case "BACK": return AndroidKey.BACK;
            case "TAB": return AndroidKey.TAB;
            case "SPACE": return AndroidKey.SPACE;
            case "DEL":
            case "DELETE": return AndroidKey.DEL;
            case "HOME": return AndroidKey.HOME;
            case "ENDCALL": return AndroidKey.ENDCALL;
            case "CALL": return AndroidKey.CALL;
            case "VOLUME_UP": return AndroidKey.VOLUME_UP;
            case "VOLUME_DOWN": return AndroidKey.VOLUME_DOWN;
            case "VOLUME_MUTE": return AndroidKey.VOLUME_MUTE;
            default:
                return null;
        }
    }

    // ==================================
    //  COMMON SCROLL UP / SCROLL DOWN
    // ==================================

    public static void scrollDown(WebDriver driver, String context) {
        System.out.println("[BDD] SCROLL_DOWN [" + context + "]");

        if (!(driver instanceof AndroidDriver)) {
            System.out.println("[PageUtility] SCROLL_DOWN ignored, driver is not AndroidDriver");
            return;
        }

        AndroidDriver android = (AndroidDriver) driver;
        Dimension size = android.manage().window().getSize();

        int startX = size.width / 2;
        int startY = (int) (size.height * 0.8);
        int endY   = (int) (size.height * 0.2);

        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence swipe = new Sequence(finger, 1);

        swipe.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), startX, startY));
        swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        swipe.addAction(finger.createPointerMove(Duration.ofMillis(500), PointerInput.Origin.viewport(), startX, endY));
        swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

        android.perform(java.util.Collections.singletonList(swipe));
    }

    public static void scrollUp(WebDriver driver, String context) {
        System.out.println("[BDD] SCROLL_UP [" + context + "]");

        if (!(driver instanceof AndroidDriver)) {
            System.out.println("[PageUtility] SCROLL_UP ignored, driver is not AndroidDriver");
            return;
        }

        AndroidDriver android = (AndroidDriver) driver;
        Dimension size = android.manage().window().getSize();

        int startX = size.width / 2;
        int startY = (int) (size.height * 0.2);
        int endY   = (int) (size.height * 0.8);

        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence swipe = new Sequence(finger, 1);

        swipe.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), startX, startY));
        swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        swipe.addAction(finger.createPointerMove(Duration.ofMillis(500), PointerInput.Origin.viewport(), startX, endY));
        swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

        android.perform(java.util.Collections.singletonList(swipe));
    }

}
