package com.example.framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.lang.reflect.Field;

/**
 * Generic helper methods to interact with generated PageObject classes that
 * expose locator constants (USERNAME1, USERNAME2, ...) and a FALLBACK_ORDER
 * string[] listing those constant names in priority order.
 */
public class PageMethods {

    private PageMethods() { }

    public static void type(WebDriver driver, Class<?> elementClass, String text) {
        String[] fallbackOrder = getFallbackOrder(elementClass);

        for (String constName : fallbackOrder) {
            try {
                Field locatorField = elementClass.getDeclaredField(constName);
                By locator = (By) locatorField.get(null);

                SauceKeepAlive.ping(driver);

                WebElement el = driver.findElement(locator);
                el.clear();
                el.sendKeys(text);
                Thread.sleep(1000);
                SauceKeepAlive.ping(driver);
                System.out.println("[PageMethods] Typed using locator: " + constName);
                return;
            } catch (Exception ignored) {
            	WriteLogToFile.addLog("[PageMethods] Locater " + constName + "Failed trying next Fallback locator");

            }
            
        }

        throw new RuntimeException("All fallback locators failed for class: " + elementClass.getSimpleName());
    }

    public static void click(WebDriver driver, Class<?> elementClass) {
        String[] fallbackOrder = getFallbackOrder(elementClass);

        for (String constName : fallbackOrder) {
            try {
                Field locatorField = elementClass.getDeclaredField(constName);
                By locator = (By) locatorField.get(null);

                SauceKeepAlive.ping(driver);

                WebElement el = driver.findElement(locator);
                el.click();
                Thread.sleep(1000);
                SauceKeepAlive.ping(driver);
                System.out.println("[PageMethods] Clicked using locator: " + constName);
                return;
            } catch (Exception ignored) {
            	WriteLogToFile.addLog("[PageMethods] Locater " + constName + "Failed trying next Fallback locator");

            }
            
        }

        throw new RuntimeException("All fallback locators failed for class: " + elementClass.getSimpleName());
    }

    private static String[] getFallbackOrder(Class<?> elementClass) {
        try {
            Field fallbackField = elementClass.getDeclaredField("FALLBACK_ORDER");
            return (String[]) fallbackField.get(null);
        } catch (Exception e) {
            throw new RuntimeException("FALLBACK_ORDER not found or not accessible on class: "
                    + elementClass.getName(), e);
        }
    }
    
}
