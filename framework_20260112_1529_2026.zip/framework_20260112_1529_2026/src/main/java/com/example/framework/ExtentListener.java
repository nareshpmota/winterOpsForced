package com.example.framework;

import org.testng.ITestListener;
import org.testng.ITestResult;
import io.appium.java_client.android.AndroidDriver;

public class ExtentListener implements ITestListener {

    public void onTestFailure(ITestResult result) {
        Object testClass = result.getInstance();
        AndroidDriver driver =
            ((BaseTest) testClass).driver;

        String path = ScreenshotUtil.captureScreenshot(
            driver, result.getName());

        ((BaseTest) testClass).test.fail(result.getThrowable())
            .addScreenCaptureFromPath(path);
    }
}

