package com.example.framework;

import java.net.MalformedURLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.aventstack.extentreports.*;
import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.AndroidDriver;


public abstract class BaseTest {

    protected AndroidDriver driver;
    protected String FinalTestName;
    protected static ExtentReports extent;
    protected ExtentTest test;
    

    @BeforeClass(alwaysRun = true)
    public void setUp() throws MalformedURLException, InterruptedException {
        String testName = this.getClass().getSimpleName();
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));

        FinalTestName = "Element Hunters " + testName + " " +timestamp;
        driver = (AndroidDriver) DriverFactory.createSauceDriver(FinalTestName);
        System.out.println("Inside Base Test class");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception ignored) {
            }
        }
    }
    
   

    @BeforeSuite
    public void setupReport() {
        extent = ExtentManager.getInstance();
    }

    @AfterSuite
    public void flushReport() {
        extent.flush();
    }
}
