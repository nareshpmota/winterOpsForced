package com.example.framework;

import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 * Creates a RemoteWebDriver session on Sauce Labs.
 * Reads credentials from env vars: SAUCE_USERNAME, SAUCE_ACCESS_KEY, SAUCE_REGION.
 * You can later modify capabilities for mobile/Appium.
 */
public class DriverFactory {
 
    public static WebDriver createSauceDriver(String testName) throws MalformedURLException, InterruptedException {
        
       System.out.println(testName);

       MutableCapabilities caps = new MutableCapabilities();
       caps.setCapability("platformName", "Android");
       caps.setCapability("appium:app", "storage:filename=WinterOps_Mobile_Toolkit_march.apk");  // The filename of the mobile app
       caps.setCapability("appium:deviceName", "Samsung_Galaxy_S25.*");
       caps.setCapability("appium:platformVersion", "15");
       caps.setCapability("appium:automationName", "UiAutomator2");
       MutableCapabilities sauceOptions = new MutableCapabilities();
       sauceOptions.setCapability("appiumVersion", "latest");
       sauceOptions.setCapability("username", "Nareshpmota");
       sauceOptions.setCapability("accessKey", "6d082911-c5bd-4694-87e3-d9bf9f41b203");
       sauceOptions.setCapability("build", "POC-WinterOps");
       sauceOptions.setCapability("name", "POC-WinterOps");
       caps.setCapability("sauce:options", sauceOptions);

//       MutableCapabilities caps = new MutableCapabilities();
//       caps.setCapability("platformName", "Android");
//       caps.setCapability("appium:app", "storage:21e5e224-3650-40bf-878f-b6d06f2b1f3f");
//       caps.setCapability("appium:deviceName", "Samsung Galaxy S25.*");
//       caps.setCapability("appium:automationName", "UiAutomator2");
//       MutableCapabilities sauceOptions = new MutableCapabilities();
//       sauceOptions.setCapability("appiumVersion", "latest");
//       sauceOptions.setCapability("username", "Nareshpmota");
//       sauceOptions.setCapability("accessKey", "6d082911-c5bd-4694-87e3-d9bf9f41b203");
//       sauceOptions.setCapability("build", "<your build id>");
//       sauceOptions.setCapability("name", "<your test name>");
//       caps.setCapability("sauce:options", sauceOptions);
//       
       // Start the session
       URL url = new URL("https://ondemand.us-west-1.saucelabs.com:443/wd/hub");
       AndroidDriver driver = new AndroidDriver(url, caps);
      
       System.out.println("===DEBUG========== DRIVER Initialized ");
     //  WriteLogToFile.addLog(driver.getPageSource());
       SauceKeepAlive.ping(driver);
       Thread.sleep(30000);
       SauceKeepAlive.ping(driver);
      // System.out.println("===DEBUG========== calling to wait ");
       waitForLoaderToDisappear(driver);
//       try {
//           driver.findElement(By.xpath(
//               "//*[@text='Allow' or @text='ALLOW' or @text='While using the app']"
//           )).click();
//       } catch (Exception e) {
//           System.out.println("Permission popup not displayed");
//       }
       
       return driver;
   }
 
    public static void waitForLoaderToDisappear(AndroidDriver driver) throws InterruptedException {

        By loader = By.xpath("//*[normalize-space(@text)='Syncing flight schedules and flight details...']");

        long timeoutMs = 600_000;           // 10 minutes
        long pollMs = 1000;                 // 1 sec
        long keepAliveMs = 50_000;          // Sauce ping

        long start = System.currentTimeMillis();
        long lastPing = start;

        // 🔹 Initial presence check — SAFE
        List<WebElement> initial = driver.findElements(loader);

        // Case 1 & 2 → loader not visible or not present
        if (initial.isEmpty() || !initial.get(0).isDisplayed()) {
            System.out.println("Loader not visible → proceeding");
            return;
        }

        System.out.println("Loader visible → waiting for disappearance");

        // Case 3 & 4 → wait until invisible
        while (System.currentTimeMillis() - start < timeoutMs) {

            List<WebElement> elements = driver.findElements(loader);

            // Loader removed from DOM
            if (elements.isEmpty()) {
                System.out.println("Loader removed from DOM → proceeding");
                return;
            }

            try {
                if (!elements.get(0).isDisplayed()) {
                    System.out.println("Loader hidden → proceeding");
                    return;
                }
            } catch (StaleElementReferenceException ignored) {
                // Loader refreshed → treat as still loading
            }

            if (System.currentTimeMillis() - lastPing >= keepAliveMs) {
                SauceKeepAlive.ping(driver);
                lastPing = System.currentTimeMillis();
            }

            Thread.sleep(pollMs);
        }

        System.out.println("Loader wait timeout → proceeding anyway");
    }


}