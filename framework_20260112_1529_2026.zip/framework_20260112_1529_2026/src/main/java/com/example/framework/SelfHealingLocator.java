package com.example.framework;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

/**
 * Runtime self-healing using GitHub Models LLM (gpt-4o-mini).
 *
 * When normal PageMethods fallback fails, we:
 *  - grab current page source
 *  - send broken locator + page source + logical name to LLM
 *  - get back a better locator
 *  - try it immediately on the SAME driver/session (Sauce/Appium)
 */
public class SelfHealingLocator {

	
    private SelfHealingLocator() {}

    public static void healAndType(
            WebDriver driver,
            Class<?> elementClass,
            String logicalName,
            String text,
            Exception originalError
    ) {
        final int MAX_ATTEMPTS = 3;

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            System.out.println("[SelfHeal] LLM heal attempt " + attempt + " for " + logicalName);
            HealedLocator HL = new HealedLocator();
            By healedBy = findHealedLocator(driver, elementClass, logicalName, originalError, HL);

            if (healedBy == null) {
                System.out.println("[SelfHeal] retry " + attempt + " = FAILED (LLM returned no locator)");
                continue;
            }

            try {
                SauceKeepAlive.ping(driver);

                WebElement el = driver.findElement(healedBy);
                el.clear();
                el.sendKeys(text);

                System.out.println("[SelfHeal] retry " + attempt + " = PASSED using healed locator: " + healedBy);
                WriteSelfHealedLocatorToLib.writeHealedLocator(
                        elementClass,
                        logicalName,
                        HL.locatorType,
                        HL.locatorValue
                );
                
            	WriteLogToFile.addLog("[SelfHeal] retry " + attempt + " = PASSED using healed locator: " + healedBy);

                return; // success, stop further attempts
            } catch (Exception e) {
                System.out.println("[SelfHeal] retry " + attempt + " = FAILED using healed locator: "
                        + healedBy + " | error: " + e.getMessage());
            }
        }

        throw new RuntimeException(
                "[SelfHeal] All LLM heal attempts failed for " + logicalName,
                originalError
        );
    }

    public static void healAndClick(
            WebDriver driver,
            Class<?> elementClass,
            String logicalName,
            Exception originalError
    ) {
        final int MAX_ATTEMPTS = 3;

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            System.out.println("[SelfHeal] LLM heal attempt " + attempt + " for " + logicalName);
            HealedLocator HL = new HealedLocator();
            By healedBy = findHealedLocator(driver, elementClass, logicalName, originalError, HL);

            if (healedBy == null) {
                System.out.println("[SelfHeal] retry " + attempt + " = FAILED (LLM returned no locator)");
                continue;
            }

            try {
                SauceKeepAlive.ping(driver);

                WebElement el = driver.findElement(healedBy);
                el.click();

                System.out.println("[SelfHeal] retry " + attempt + " = PASSED using healed locator: " + healedBy);
            	WriteLogToFile.addLog("[SelfHeal] retry " + attempt + " = PASSED using healed locator: " + healedBy);
            	  WriteSelfHealedLocatorToLib.writeHealedLocator(
                          elementClass,
                          logicalName,
                          HL.locatorType,
                          HL.locatorValue
                  );
                return; // success, stop further attempts
            } catch (Exception e) {
                System.out.println("[SelfHeal] retry " + attempt + " = FAILED using healed locator: "
                        + healedBy + " | error: " + e.getMessage());
            }
        }

        throw new RuntimeException(
                "[SelfHeal] All LLM heal attempts failed for " + logicalName,
                originalError
        );
    }

    private static By findHealedLocator(
            WebDriver driver,
            Class<?> elementClass,
            String logicalName,
            Exception originalError,
            HealedLocator HL1
    ) {
        try {
            SauceKeepAlive.ping(driver);

            String pageSource = driver.getPageSource();
            String originalLocatorsDescription = describeOriginalLocators(elementClass);
            String prompt = buildPrompt(logicalName, originalLocatorsDescription, pageSource, originalError);

            String llmJson = callLlm(prompt);
            HealedLocator healed = parseHealedLocator(llmJson);
            if (healed == null || healed.locatorValue == null || healed.locatorValue.isBlank()) {
                System.out.println("[SelfHeal] LLM did not return a usable locator for " + logicalName);
                return null;
            }

            System.out.println("[SelfHeal] LLM suggested locatorType=" + healed.locatorType +
                    ", locatorValue=" + healed.locatorValue);
             HL1.locatorType = healed.locatorType;
             HL1.locatorValue = healed.locatorValue;
            return toBy(healed);

        } catch (Exception e) {
            System.out.println("[SelfHeal] Error during LLM healing for " + logicalName + ": " + e.getMessage());
            return null;
        }
    }

    private static class HealedLocator {
        String locatorType;
        String locatorValue;
    }

    private static String describeOriginalLocators(Class<?> elementClass) {
        StringBuilder sb = new StringBuilder();
        try {
            Field fallbackField = elementClass.getDeclaredField("FALLBACK_ORDER");
            String[] order = (String[]) fallbackField.get(null);
            sb.append("Original fallback constants: ");
            for (String name : order) {
                try {
                    Field f = elementClass.getDeclaredField(name);
                    Object value = f.get(null);
                    sb.append(name).append(" = ").append(String.valueOf(value)).append("; ");
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            sb.append("No FALLBACK_ORDER available.");
        }
        return sb.toString();
    }

    private static String buildPrompt(
            String logicalName,
            String originalLocatorsDescription,
            String pageSource,
            Exception originalError
    ) {
        return "You are a test automation locator healing assistant.\n\n" +
                "The test is failing to locate element: " + logicalName + "\n\n" +
                "Original locator attempts:\n" + originalLocatorsDescription + "\n\n" +
                "The automation is currently on this mobile/web page:\n" +
                "---- PAGE SOURCE START ----\n" +
                pageSource +
                "\n---- PAGE SOURCE END ----\n\n" +
                "The last error was:\n" + originalError.toString() + "\n\n" +
                "Task:\n" +
                "- Find the BEST locator for this element.\n" +
                "- The locator must be actually present in the page source.\n" +
                "- Prefer stable locators: resource-id / id / accessibility id / content-desc first, then xpath.\n" +
                "- DO NOT invent attributes that do not exist in the page source.\n" +
                "- If the original locator had a small typo (e.g. '@resourceeeID' vs '@resource-id'), correct it.\n\n" +
                "Output ONLY JSON in this exact format:\n" +
                "{\n" +
                "  \"locatorType\": \"xpath | id | accessibilityId | css\",\n" +
                "  \"locatorValue\": \"...\"\n" +
                "}";
    }

    private static String callLlm(String prompt) throws Exception {
        String token = "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";
        if (token == null || token.isBlank()) {
            throw new IllegalStateException("GITHUB_TOKEN env var not set");
        }
        String model = System.getenv("GITHUB_MODEL_ID");
        if (model == null || model.isBlank()) {
            model = "gpt-4o-mini";
        }

        HttpClient client = HttpClient.newHttpClient();
        String url = "https://models.inference.ai.azure.com/chat/completions";

        JSONObject body = new JSONObject();
        body.put("max_tokens", 512);
        body.put("temperature", 0.2);
        body.put("model",model );

        JSONArray messages = new JSONArray();
        JSONObject sys = new JSONObject();
        sys.put("role", "system");
        sys.put("content", "You are a JSON-only assistant. Respond with JSON only.");
        messages.put(sys);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", prompt);
        messages.put(user);
        body.put("messages", messages);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("X-Model", "gpt-4o-mini")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        int status = response.statusCode();
        String respBody = response.body();
        System.out.println("[SelfHeal] LLM HTTP status: " + status);

        if (status != 200) {
            throw new RuntimeException("LLM call failed: status=" + status + " body=" + respBody);
        }

        JSONObject root = new JSONObject(respBody);
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.isEmpty()) {
            throw new RuntimeException("LLM response has no choices");
        }
        JSONObject first = choices.getJSONObject(0);
        JSONObject message = first.getJSONObject("message");
        String content = message.getString("content");
        return content;
    }

    private static HealedLocator parseHealedLocator(String json) {
        if (json == null || json.isBlank()) return null;
        try {
            JSONObject obj = new JSONObject(json);
            HealedLocator hl = new HealedLocator();
            hl.locatorType = obj.optString("locatorType", null);
            hl.locatorValue = obj.optString("locatorValue", null);
            return hl;
        } catch (Exception e) {
            System.out.println("[SelfHeal] Failed to parse LLM JSON: " + e.getMessage());
            return null;
        }
    }

    private static By toBy(HealedLocator healed) {
        String t = healed.locatorType == null ? "" : healed.locatorType.toLowerCase();
        String v = healed.locatorValue;

        switch (t) {
            case "id":
                return By.id(v);
            case "accessibilityid":
            case "accessibility_id":
            case "accessibility":
                return By.xpath("//*[@content-desc='" + v + "']");
            case "css":
                return By.cssSelector(v);
            case "xpath":
            default:
                return By.xpath(v);
        }
    }
}
