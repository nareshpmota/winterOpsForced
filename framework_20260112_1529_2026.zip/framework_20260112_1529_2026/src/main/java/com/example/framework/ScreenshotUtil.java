package com.example.framework;


import org.openqa.selenium.*;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;

public class ScreenshotUtil {

    public static String captureScreenshot(WebDriver driver, String testName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File src = ts.getScreenshotAs(OutputType.FILE);

            String path = "test-output/screenshots/" + testName + ".png";
            FileUtils.copyFile(src, new File(path));

            return path;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
