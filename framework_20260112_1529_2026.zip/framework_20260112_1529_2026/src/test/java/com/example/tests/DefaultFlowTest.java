package com.example.tests;

import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import com.example.framework.BaseTest;
import com.example.pages.*;

/**
 * Auto-generated skeleton test from BDD script.
 * BDD at generation time:
 * ------------------------------------------------------------
 * START
 * SCREEN SelectStation
 * EXPECT_SCREEN SelectStation
 * CLICK SELECT_AN_ITEM
 * KEY_TAP "A"
 * KEY_TAP "B"
 * KEY_TAP "E"
 * KEY_TAP "ENTER"
 * CLICK SAVE
 * WAIT 1
 * SCREEN PPR_Login
 * TYPE "008720216" INTO Input_EmployeeNumberValue
 * CLICK CONTINUE
 * SCREEN PreviewScreen
 * EXPECT_SCREEN PreviewScreen
 * WAIT 1
 * CLICK TRUCK_INFORMATION_BUTTON
 * SCREEN TruckInformation
 * EXPECT_SCREEN TruckInformation
 * TYPE "TEST Vehicle" INTO VEHICLE_NUMBER_INPUT
 * CLICK INSPECT_VEHICLE_COMPLETE_POI_CHECKBOX
 * CLICK CHECKBOX1
 * CLICK FLUID_TYPE_I_FREEZE_POINT_INPUT
 * KEY_TAP "-"
 * KEY_TAP "1"
 * KEY_TAP "0"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK FLUID_TYPE_I_DILUTION_INPUT
 * KEY_TAP "3"
 * KEY_TAP "0"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK FluidTypeIV_Dilution
 * REFRESH
 * CLICK 75
 * SCROLL_DOWN
 * CLICK FLUID_TYPE_IV_RI
 * KEY_TAP "1"
 * KEY_TAP "0"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * CLICK SAVE
 * WAIT 1
 * SCREEN PreviewScreen
 * EXPECT_SCREEN PreviewScreen
 * CLICK Start_New_Log
 * WAIT 1
 * SCREEN OperatorsScreen
 * EXPECT_SCREEN OperatorsScreen
 * TYPE "008783159" INTO Input_SprayerPersonNumber
 * KEY_TAP_CLOSE
 * WAIT 1
 * CLICK Continue
 * WAIT 1
 * SCREEN LogDetails
 * EXPECT_SCREEN LogDetails
 * CLICK Customer AFTER
 * REFRESH
 * CLICK UNITED_AIRLINES
 * TAP 3 2
 * WAIT 2
 * REFRESH
 * CLICK click_INPUT_VDRIVERNUMBER3
 * TYPE "N068799" INTO type_INPUT_VDRIVERNUMBER3
 * CLICK Input_VSprayerrNumber3
 * TYPE "A000743" INTO Input_VSprayerrNumber3
 * CLICK CHECK
 * CLICK Weather_Condition AFTER
 * REFRESH
 * CLICK Slush
 * CLICK No_input
 * REFRESH
 * TYPE "DL TEST FN" INTO Input_FlightNumber
 * KEY_TAP_CLOSE
 * CLICK RegNotFount_input
 * REFRESH
 * TYPE "DL TEST ARN" INTO Input_AircraftRegistrationNumber
 * KEY_TAP_CLOSE
 * TYPE "TEST" INTO Input_AircraftShipNumber
 * TYPE "TEST AIR LOCATION" INTO Input_AircraftLocation
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK Input_OutdoorAirTemperature
 * KEY_TAP "1"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK Checkbox3
 * TYPE "TEST" INTO HID
 * KEY_TAP_CLOSE
 * TYPE "TEST" INTO HID2
 * KEY_TAP_CLOSE
 * CLICK CONTINUE
 * WAIT 2
 * SCREEN Fluid_Application
 * EXPECT_SCREEN Fluid_Application
 * CLICK Entire_Aircraft BEFORE
 * CLICK CONTINUE
 * WAIT 2
 * SCREEN FluidTypeSelection
 * EXPECT_SCREEN FluidTypeSelection
 * CLICK Add_Type_I BEFORE
 * WAIT 2
 * SCREEN Type_I_Fluid_Application
 * CLICK Type_I_Used
 * REFRESH
 * CLICK Input_FluidTypeI_StartDateTime
 * REFRESH
 * CLICK SET
 * CLICK Input_FluidTypeI_EndDateTime
 * REFRESH
 * CLICK SET
 * SCROLL_DOWN
 * REFRESH
 * CLICK Type_I_Gallons_Applied
 * KEY_TAP "1"
 * KEY_TAP "0"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK SAVE
 * WAIT 2
 * SCREEN FluidTypeSelection
 * EXPECT_SCREEN FluidTypeSelection
 * CLICK Add_Type_IV BEFORE
 * WAIT 2
 * SCREEN Type_IV_Fluid_Application
 * CLICK Type_IV_Used
 * REFRESH
 * CLICK Input_FluidTypeI_StartDateTime
 * REFRESH
 * CLICK SET
 * CLICK Input_FluidTypeI_EndDateTime
 * REFRESH
 * CLICK SET
 * SCROLL_DOWN
 * REFRESH
 * CLICK Type_IV_Gallons_Applied
 * KEY_TAP "2"
 * KEY_TAP "0"
 * KEY_TAP_CLOSE
 * SCROLL_DOWN
 * REFRESH
 * CLICK SAVE
 * WAIT 2
 * SCREEN FluidTypeSelection
 * EXPECT_SCREEN FluidTypeSelection
 * CLICK CONTINUE
 * WAIT 2
 * SCREEN SUMMARY
 * EXPECT_SCREEN SUMMARY
 * SCROLL_DOWN
 * SCROLL_DOWN
 * SCROLL_DOWN
 * REFRESH
 * CLICK AcknowledgmentCheckBox
 * TYPE "TEST COMMENTS" INTO TextArea_Comment
 * CLICK Submit
 * WAIT 5
 * END
 * ------------------------------------------------------------
 */
public class DefaultFlowTest extends BaseTest {

    @Test
    public void defaultBddFlow() throws Exception {
 test = extent.createTest("End to End Deice Log flow Testing");
test.info(" START " ); 
        // BDD (no PageMethods mapping): START

test.info(" SCREEN SelectStation " ); 

        // --- SCREEN SelectStation ---
        SelectStationPageMethods selectStation = new SelectStationPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN SelectStation " ); 
        // BDD: EXPECT_SCREEN SelectStation
        selectStation.expectSelectStationScreen();

test.info(" CLICK SELECTANITEM " ); 
        // BDD: CLICK SELECT_AN_ITEM
        selectStation.clickSelectAnItem();

test.info(" KEYTAP A " ); 
        // BDD: KEY_TAP "A"
        selectStation.keyTap("A");

test.info(" KEYTAP B " ); 
        // BDD: KEY_TAP "B"
        selectStation.keyTap("B");

test.info(" KEYTAP E " ); 
        // BDD: KEY_TAP "E"
        selectStation.keyTap("E");

test.info(" KEYTAP ENTER " ); 
        // BDD: KEY_TAP "ENTER"
        selectStation.keyTapEnter();

test.info(" CLICK SAVE " ); 
        // BDD: CLICK SAVE
        selectStation.clickSave();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        selectStation.waitSeconds(1);

test.info(" SCREEN PPRLogin " ); 

        // --- SCREEN PPR_Login ---
        PPRLoginPageMethods pPRLogin = new PPRLoginPageMethods((AndroidDriver) driver);
test.info(" TYPE 008720216 INTO InputEmployeeNumberValue " ); 
        // BDD: TYPE "008720216" INTO Input_EmployeeNumberValue
        pPRLogin.typeInputEmployeenumbervalue("008720216");

test.info(" CLICK CONTINUE " ); 
        // BDD: CLICK CONTINUE
        pPRLogin.clickContinue();

test.info(" SCREEN PreviewScreen " ); 

        // --- SCREEN PreviewScreen ---
        PreviewPageMethods preview = new PreviewPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN PreviewScreen " ); 
        // BDD: EXPECT_SCREEN PreviewScreen
        preview.expectPreviewScreen();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        preview.waitSeconds(1);

test.info(" CLICK TRUCKINFORMATIONBUTTON " ); 
        // BDD: CLICK TRUCK_INFORMATION_BUTTON
        preview.clickTruckInformationButton();

test.info(" SCREEN TruckInformation " ); 

        // --- SCREEN TruckInformation ---
        TruckInformationPageMethods truckInformation = new TruckInformationPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN TruckInformation " ); 
        // BDD: EXPECT_SCREEN TruckInformation
        truckInformation.expectTruckInformationScreen();

test.info(" TYPE TEST Vehicle INTO VEHICLENUMBERINPUT " ); 
        // BDD: TYPE "TEST Vehicle" INTO VEHICLE_NUMBER_INPUT
        truckInformation.typeVehicleNumberInput("TEST Vehicle");

test.info(" CLICK INSPECTVEHICLECOMPLETEPOICHECKBOX " ); 
        // BDD: CLICK INSPECT_VEHICLE_COMPLETE_POI_CHECKBOX
        truckInformation.clickInspectVehicleCompletePoiCheckbox();

test.info(" CLICK CHECKBOX1 " ); 
        // BDD: CLICK CHECKBOX1
        truckInformation.clickCheckbox1();

test.info(" CLICK FLUIDTYPEIFREEZEPOINTINPUT " ); 
        // BDD: CLICK FLUID_TYPE_I_FREEZE_POINT_INPUT
        truckInformation.clickFluidTypeIFreezePointInput();

test.info(" KEYTAP  " ); 
        // BDD: KEY_TAP "-"
        truckInformation.keyTap("-");

test.info(" KEYTAP 1 " ); 
        // BDD: KEY_TAP "1"
        truckInformation.keyTap("1");

test.info(" KEYTAP 0 " ); 
        // BDD: KEY_TAP "0"
        truckInformation.keyTap("0");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        truckInformation.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        truckInformation.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        truckInformation.refresh();

test.info(" CLICK FLUIDTYPEIDILUTIONINPUT " ); 
        // BDD: CLICK FLUID_TYPE_I_DILUTION_INPUT
        truckInformation.clickFluidTypeIDilutionInput();

test.info(" KEYTAP 3 " ); 
        // BDD: KEY_TAP "3"
        truckInformation.keyTap("3");

test.info(" KEYTAP 0 " ); 
        // BDD: KEY_TAP "0"
        truckInformation.keyTap("0");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        truckInformation.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        truckInformation.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        truckInformation.refresh();

test.info(" CLICK FluidTypeIVDilution " ); 
        // BDD: CLICK FluidTypeIV_Dilution
        truckInformation.clickFluidtypeivDilution();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        truckInformation.refresh();

test.info(" CLICK 75 " ); 
        // BDD: CLICK 75
        truckInformation.click75();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        truckInformation.scrollDown();

test.info(" CLICK FLUIDTYPEIVRI " ); 
        // BDD: CLICK FLUID_TYPE_IV_RI
        truckInformation.clickFluidTypeIvRi();

test.info(" KEYTAP 1 " ); 
        // BDD: KEY_TAP "1"
        truckInformation.keyTap("1");

test.info(" KEYTAP 0 " ); 
        // BDD: KEY_TAP "0"
        truckInformation.keyTap("0");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        truckInformation.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        truckInformation.scrollDown();

test.info(" CLICK SAVE " ); 
        // BDD: CLICK SAVE
        truckInformation.clickSave();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        truckInformation.waitSeconds(1);

test.info(" SCREEN PreviewScreen " ); 

        // --- SCREEN PreviewScreen ---
        // Reusing existing PreviewPageMethods instance
test.info(" EXPECTSCREEN PreviewScreen " ); 
        // BDD: EXPECT_SCREEN PreviewScreen
        preview.expectPreviewScreen();

test.info(" CLICK StartNewLog " ); 
        // BDD: CLICK Start_New_Log
        preview.clickStartNewLog();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        preview.waitSeconds(1);

test.info(" SCREEN OperatorsScreen " ); 

        // --- SCREEN OperatorsScreen ---
        OperatorsPageMethods operators = new OperatorsPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN OperatorsScreen " ); 
        // BDD: EXPECT_SCREEN OperatorsScreen
        operators.expectOperatorsScreen();

test.info(" TYPE 008783159 INTO InputSprayerPersonNumber " ); 
        // BDD: TYPE "008783159" INTO Input_SprayerPersonNumber
        operators.typeInputSprayerpersonnumber("008783159");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        operators.keyTapClose();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        operators.waitSeconds(1);

test.info(" CLICK Continue " ); 
        // BDD: CLICK Continue
        operators.clickContinue();

test.info(" WAIT 1 " ); 
        // BDD: WAIT 1
        operators.waitSeconds(1);

test.info(" SCREEN LogDetails " ); 

        // --- SCREEN LogDetails ---
        LogDetailsPageMethods logDetails = new LogDetailsPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN LogDetails " ); 
        // BDD: EXPECT_SCREEN LogDetails
        logDetails.expectLogDetailsScreen();

test.info(" CLICK Customer AFTER " ); 
        // BDD: CLICK Customer AFTER
        logDetails.clickCustomer();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" CLICK UNITEDAIRLINES " ); 
        // BDD: CLICK UNITED_AIRLINES
        logDetails.clickUnitedAirlines();

test.info(" TAP 3 2 " ); 
        // BDD: TAP 3 2
        logDetails.tapGrid(3, 2);

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        logDetails.waitSeconds(2);

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" CLICK clickINPUTVDRIVERNUMBER3 " ); 
        // BDD: CLICK click_INPUT_VDRIVERNUMBER3
        logDetails.clickClickInputVdrivernumber3();

test.info(" TYPE N068799 INTO typeINPUTVDRIVERNUMBER3 " ); 
        // BDD: TYPE "N068799" INTO type_INPUT_VDRIVERNUMBER3
        logDetails.typeTypeInputVdrivernumber3("N068799");

test.info(" CLICK InputVSprayerrNumber3 " ); 
        // BDD (no PageMethods mapping): CLICK Input_VSprayerrNumber3
      logDetails.clickInputVsprayerrnumber3(); // Page method is not bind or avaialble for this test step please check

test.info(" TYPE A000743 INTO InputVSprayerrNumber3 " ); 
        // BDD: TYPE "A000743" INTO Input_VSprayerrNumber3
        logDetails.typeInputVsprayerrnumber3("A000743");

test.info(" CLICK CHECK " ); 
        // BDD: CLICK CHECK
        logDetails.clickCheck();

test.info(" CLICK WeatherCondition AFTER " ); 
        // BDD: CLICK Weather_Condition AFTER
        logDetails.clickWeatherCondition();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" CLICK Slush " ); 
        // BDD: CLICK Slush
        logDetails.clickSlush();

test.info(" CLICK Noinput " ); 
        // BDD: CLICK No_input
        logDetails.clickNoInput();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" TYPE DL TEST FN INTO InputFlightNumber " ); 
        // BDD: TYPE "DL TEST FN" INTO Input_FlightNumber
        logDetails.typeInputFlightnumber("DL TEST FN");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" CLICK RegNotFountinput " ); 
        // BDD: CLICK RegNotFount_input
        logDetails.clickRegnotfountInput();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" TYPE DL TEST ARN INTO InputAircraftRegistrationNumber " ); 
        // BDD: TYPE "DL TEST ARN" INTO Input_AircraftRegistrationNumber
        logDetails.typeInputAircraftregistrationnumber("DL TEST ARN");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" TYPE TEST INTO InputAircraftShipNumber " ); 
        // BDD: TYPE "TEST" INTO Input_AircraftShipNumber
        logDetails.typeInputAircraftshipnumber("TEST");

test.info(" TYPE TEST AIR LOCATION INTO InputAircraftLocation " ); 
        // BDD: TYPE "TEST AIR LOCATION" INTO Input_AircraftLocation
        logDetails.typeInputAircraftlocation("TEST AIR LOCATION");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        logDetails.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" CLICK InputOutdoorAirTemperature " ); 
        // BDD: CLICK Input_OutdoorAirTemperature
        logDetails.clickInputOutdoorairtemperature();

test.info(" KEYTAP 1 " ); 
        // BDD: KEY_TAP "1"
        logDetails.keyTap("1");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        logDetails.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        logDetails.refresh();

test.info(" CLICK Checkbox3 " ); 
        // BDD: CLICK Checkbox3
        logDetails.clickCheckbox3();

test.info(" TYPE TEST INTO HID " ); 
        // BDD: TYPE "TEST" INTO HID
        logDetails.typeHid("TEST");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" TYPE TEST INTO HID2 " ); 
        // BDD: TYPE "TEST" INTO HID2
        logDetails.typeHid2("TEST");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        logDetails.keyTapClose();

test.info(" CLICK CONTINUE " ); 
        // BDD: CLICK CONTINUE
        logDetails.clickContinue();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        logDetails.waitSeconds(2);

test.info(" SCREEN FluidApplication " ); 

        // --- SCREEN Fluid_Application ---
        FluidApplicationPageMethods fluidApplication = new FluidApplicationPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN FluidApplication " ); 
        // BDD: EXPECT_SCREEN Fluid_Application
        fluidApplication.expectFluidApplicationScreen();

test.info(" CLICK EntireAircraft BEFORE " ); 
        // BDD: CLICK Entire_Aircraft BEFORE
        fluidApplication.clickEntireAircraft();

test.info(" CLICK CONTINUE " ); 
        // BDD: CLICK CONTINUE
        fluidApplication.clickContinue();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        fluidApplication.waitSeconds(2);

test.info(" SCREEN FluidTypeSelection " ); 

        // --- SCREEN FluidTypeSelection ---
        FluidTypeSelectionPageMethods fluidTypeSelection = new FluidTypeSelectionPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN FluidTypeSelection " ); 
        // BDD: EXPECT_SCREEN FluidTypeSelection
        fluidTypeSelection.expectFluidTypeSelectionScreen();

test.info(" CLICK AddTypeI BEFORE " ); 
        // BDD: CLICK Add_Type_I BEFORE
        fluidTypeSelection.clickAddTypeI();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        fluidTypeSelection.waitSeconds(2);

test.info(" SCREEN TypeIFluidApplication " ); 

        // --- SCREEN Type_I_Fluid_Application ---
        TypeIFluidApplicationPageMethods typeIFluidApplication = new TypeIFluidApplicationPageMethods((AndroidDriver) driver);
test.info(" CLICK TypeIUsed " ); 
        // BDD: CLICK Type_I_Used
        typeIFluidApplication.clickTypeIUsed();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIFluidApplication.refresh();

test.info(" CLICK InputFluidTypeIStartDateTime " ); 
        // BDD: CLICK Input_FluidTypeI_StartDateTime
        typeIFluidApplication.clickInputFluidtypeiStartdatetime();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIFluidApplication.refresh();

test.info(" CLICK SET " ); 
        // BDD: CLICK SET
        typeIFluidApplication.clickSet();

test.info(" CLICK InputFluidTypeIEndDateTime " ); 
        // BDD: CLICK Input_FluidTypeI_EndDateTime
        typeIFluidApplication.clickInputFluidtypeiEnddatetime();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIFluidApplication.refresh();

test.info(" CLICK SET " ); 
        // BDD: CLICK SET
        typeIFluidApplication.clickSet();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        typeIFluidApplication.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIFluidApplication.refresh();

test.info(" CLICK TypeIGallonsApplied " ); 
        // BDD: CLICK Type_I_Gallons_Applied
        typeIFluidApplication.clickTypeIGallonsApplied();

test.info(" KEYTAP 1 " ); 
        // BDD: KEY_TAP "1"
        typeIFluidApplication.keyTap("1");

test.info(" KEYTAP 0 " ); 
        // BDD: KEY_TAP "0"
        typeIFluidApplication.keyTap("0");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        typeIFluidApplication.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        typeIFluidApplication.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIFluidApplication.refresh();

test.info(" CLICK SAVE " ); 
        // BDD: CLICK SAVE
        typeIFluidApplication.clickSave();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        typeIFluidApplication.waitSeconds(2);

test.info(" SCREEN FluidTypeSelection " ); 

        // --- SCREEN FluidTypeSelection ---
        // Reusing existing FluidTypeSelectionPageMethods instance
test.info(" EXPECTSCREEN FluidTypeSelection " ); 
        // BDD: EXPECT_SCREEN FluidTypeSelection
        fluidTypeSelection.expectFluidTypeSelectionScreen();

test.info(" CLICK AddTypeIV BEFORE " ); 
        // BDD: CLICK Add_Type_IV BEFORE
        fluidTypeSelection.clickAddTypeIv();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        fluidTypeSelection.waitSeconds(2);

test.info(" SCREEN TypeIVFluidApplication " ); 

        // --- SCREEN Type_IV_Fluid_Application ---
        TypeIVFluidApplicationPageMethods typeIVFluidApplication = new TypeIVFluidApplicationPageMethods((AndroidDriver) driver);
test.info(" CLICK TypeIVUsed " ); 
        // BDD: CLICK Type_IV_Used
        typeIVFluidApplication.clickTypeIvUsed();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIVFluidApplication.refresh();

test.info(" CLICK InputFluidTypeIStartDateTime " ); 
        // BDD: CLICK Input_FluidTypeI_StartDateTime
        typeIVFluidApplication.clickInputFluidtypeiStartdatetime();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIVFluidApplication.refresh();

test.info(" CLICK SET " ); 
        // BDD: CLICK SET
        typeIVFluidApplication.clickSet();

test.info(" CLICK InputFluidTypeIEndDateTime " ); 
        // BDD: CLICK Input_FluidTypeI_EndDateTime
        typeIVFluidApplication.clickInputFluidtypeiEnddatetime();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIVFluidApplication.refresh();

test.info(" CLICK SET " ); 
        // BDD: CLICK SET
        typeIVFluidApplication.clickSet();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        typeIVFluidApplication.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIVFluidApplication.refresh();

test.info(" CLICK TypeIVGallonsApplied " ); 
        // BDD: CLICK Type_IV_Gallons_Applied
        typeIVFluidApplication.clickTypeIvGallonsApplied();

test.info(" KEYTAP 2 " ); 
        // BDD: KEY_TAP "2"
        typeIVFluidApplication.keyTap("2");

test.info(" KEYTAP 0 " ); 
        // BDD: KEY_TAP "0"
        typeIVFluidApplication.keyTap("0");

test.info(" KEYTAPCLOSE " ); 
        // BDD: KEY_TAP_CLOSE
        typeIVFluidApplication.keyTapClose();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        typeIVFluidApplication.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        typeIVFluidApplication.refresh();

test.info(" CLICK SAVE " ); 
        // BDD: CLICK SAVE
        typeIVFluidApplication.clickSave();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        typeIVFluidApplication.waitSeconds(2);

test.info(" SCREEN FluidTypeSelection " ); 

        // --- SCREEN FluidTypeSelection ---
        // Reusing existing FluidTypeSelectionPageMethods instance
test.info(" EXPECTSCREEN FluidTypeSelection " ); 
        // BDD: EXPECT_SCREEN FluidTypeSelection
        fluidTypeSelection.expectFluidTypeSelectionScreen();

test.info(" CLICK CONTINUE " ); 
        // BDD: CLICK CONTINUE
        fluidTypeSelection.clickContinue();

test.info(" WAIT 2 " ); 
        // BDD: WAIT 2
        fluidTypeSelection.waitSeconds(2);

test.info(" SCREEN SUMMARY " ); 

        // --- SCREEN SUMMARY ---
        SUMMARYPageMethods sUMMARY = new SUMMARYPageMethods((AndroidDriver) driver);
test.info(" EXPECTSCREEN SUMMARY " ); 
        // BDD: EXPECT_SCREEN SUMMARY
        sUMMARY.expectSUMMARYScreen();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        sUMMARY.scrollDown();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        sUMMARY.scrollDown();

test.info(" SCROLLDOWN " ); 
        // BDD: SCROLL_DOWN
        sUMMARY.scrollDown();

test.info(" REFRESH " ); 
        // BDD: REFRESH
        sUMMARY.refresh();

test.info(" CLICK AcknowledgmentCheckBox " ); 
        // BDD: CLICK AcknowledgmentCheckBox
        sUMMARY.clickAcknowledgmentcheckbox();

test.info(" TYPE TEST COMMENTS INTO TextAreaComment " ); 
        // BDD: TYPE "TEST COMMENTS" INTO TextArea_Comment
        sUMMARY.typeTextareaComment("TEST COMMENTS");

test.info(" CLICK Submit " ); 
        // BDD: CLICK Submit
        sUMMARY.clickSubmit();

test.info(" WAIT 5 " ); 
        // BDD: WAIT 5
        sUMMARY.waitSeconds(5);

test.info(" END " ); 
        // BDD (no PageMethods mapping): END

test.pass(" Deice log is created " );    }

}
